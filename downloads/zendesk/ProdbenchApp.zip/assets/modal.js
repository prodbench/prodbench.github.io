import{_ as e,f as t,n,p as r,t as i,v as a,x as o,y as s}from"./jsx-runtime.js";var c=o(s(),1),l=a(),u=i(),d=e.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: ${e=>e.$standalone?`auto`:`100%`};
  width: 100%;
  height: ${e=>e.$standalone?`auto`:`100%`};
  padding: ${e=>e.$standalone?`0`:`16px`};
  background: ${e=>e.$standalone?`transparent`:`rgba(36, 52, 68, 0.45)`};
`,f=e.div`
  width: ${e=>e.$standalone?`100%`:`min(560px, 100%)`};
  max-height: ${e=>e.$standalone?`100%`:`80vh`};
  min-height: auto;
  overflow: hidden;
  background: ${e=>n({theme:e.theme,variable:`background.default`})};
  border-radius: ${e=>e.$standalone?`0`:`8px`};
  box-shadow: ${e=>e.$standalone?`none`:`0 12px 32px rgba(36, 52, 68, 0.22)`};
  display: flex;
  flex-direction: column;
`,p=e.div`
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 12px 14px;
  border-bottom: 1px solid ${e=>n({theme:e.theme,variable:`border.default`})};
`,m=e.div`
  font-size: 14px;
  font-weight: 600;
  color: ${e=>n({theme:e.theme,variable:`foreground.default`})};
`,h=e.div`
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 14px;
  overflow-x: hidden;
  overflow-y: auto;
  font-size: 12px;
  line-height: 1.55;
  color: ${e=>n({theme:e.theme,variable:`foreground.default`})};
  overflow-wrap: anywhere;
  word-break: break-word;

  * {
    box-sizing: border-box;
    max-width: 100%;
  }

  p:first-child {
    margin-top: 0;
  }

  p:last-child {
    margin-bottom: 0;
  }

  ul,
  ol {
    padding-left: 18px;
  }

  a {
    color: #1f73b7;
    overflow-wrap: anywhere;
  }

  img {
    display: block;
    max-width: 100%;
    height: auto;
    max-height: 180px;
    object-fit: contain;
    margin: 8px 0;
  }
`,g=({isOpen:e,title:t,htmlContent:n,onClose:r,standalone:i=!1})=>e?(0,u.jsx)(d,{$standalone:i,children:(0,u.jsxs)(f,{$standalone:i,children:[(0,u.jsx)(p,{children:(0,u.jsx)(m,{children:t||`Details`})}),(0,u.jsx)(h,{dangerouslySetInnerHTML:{__html:n||`<p>No details available.</p>`}})]})}):null,_=new URLSearchParams(window.location.search),v=_.get(`colorScheme`),y=`720px`,b=`260px`,x=e.div`
  background-color: ${e=>n({theme:e.theme,variable:`background.default`})};
  min-height: 100vh;
  font-family: Lato, "Helvetica Neue", Helvetica, Arial, sans-serif;
  color: ${e=>n({theme:e.theme,variable:`foreground.default`})};

  * {
    font-family: inherit;
  }
`;(0,l.createRoot)(document.getElementById(`root`)).render((0,u.jsx)(()=>{let[e,n]=(0,c.useState)(v||`light`),i=(0,c.useMemo)(()=>window.ZAFClient?window.ZAFClient.init():null,[]);(0,c.useEffect)(()=>{i&&(i.invoke(`resize`,{width:y,height:b}).catch(e=>{console.error(`Failed to resize modal instance:`,e)}),i.on(`colorScheme.changed`,e=>n(e)))},[i]);let a=()=>{i&&i.invoke(`destroy`).catch(e=>{console.error(`Failed to close modal instance:`,e)})};return(0,u.jsx)(t,{theme:{...r,colors:{...r.colors,base:e}},children:(0,u.jsx)(x,{children:(0,u.jsx)(g,{isOpen:!0,title:_.get(`title`)||`Details`,htmlContent:_.get(`content`)||`<p>No details available.</p>`,onClose:a,standalone:!0})})})},{}));