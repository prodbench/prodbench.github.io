import{_ as e,a as t,b as n,c as r,d as i,f as a,g as o,h as s,i as c,l,m as u,n as d,o as f,p,r as m,s as h,t as g,u as _,v,x as y,y as b}from"./jsx-runtime.js";var x=n(((e,t)=>{t.exports=`SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED`})),S=n(((e,t)=>{var n=x();function r(){}function i(){}i.resetWarningCache=r,t.exports=function(){function e(e,t,r,i,a,o){if(o!==n){var s=Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw s.name=`Invariant Violation`,s}}e.isRequired=e;function t(){return e}var a={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:t,element:e,elementType:e,instanceOf:t,node:e,objectOf:t,oneOf:t,oneOfType:t,shape:t,exact:t,checkPropTypes:i,resetWarningCache:r};return a.PropTypes=a,a}})),C=n(((e,t)=>{t.exports=S()()}));function w(e,t){let n=t.theme?.components;if(!n)return;let r=n[e];return typeof r==`function`?r(t):r}var T=e=>{let t,n=e.theme.components,r=e.componentId||e[`data-garden-id`];return n&&r&&(t=n[r],typeof t==`function`&&(t=t(e))),t},E={black:`#000`,white:`#fff`,product:{support:`#00a656`,message:`#37b8af`,explore:`#30aabc`,gather:`#f6c8be`,guide:`#eb4962`,connect:`#ff6224`,chat:`#f79a3e`,talk:`#efc93d`,sell:`#c38f00`},grey:{100:`#f8f9f9`,200:`#e9ebed`,300:`#d8dcde`,400:`#c2c8cc`,500:`#87929d`,600:`#68737d`,700:`#49545c`,800:`#2f3941`},blue:{100:`#edf7ff`,200:`#cee2f2`,300:`#adcce4`,400:`#5293c7`,500:`#337fbd`,600:`#1f73b7`,700:`#144a75`,800:`#0f3554`},red:{100:`#fff0f1`,200:`#f5d5d8`,300:`#f5b5ba`,400:`#e35b66`,500:`#d93f4c`,600:`#cc3340`,700:`#8c232c`,800:`#681219`},yellow:{100:`#fff7ed`,200:`#ffeedb`,300:`#fed6a8`,400:`#ffb057`,500:`#f79a3e`,600:`#ed8f1c`,700:`#ad5918`,800:`#703815`},green:{100:`#edf8f4`,200:`#d1e8df`,300:`#aecfc2`,400:`#5eae91`,500:`#228f67`,600:`#038153`,700:`#186146`,800:`#0b3b29`},kale:{100:`#f5fcfc`,200:`#daeded`,300:`#bdd9d7`,400:`#90bbbb`,500:`#498283`,600:`#17494d`,700:`#03363d`,800:`#012b30`},fuschia:{400:`#d653c2`,600:`#a81897`,M400:`#cf62a8`,M600:`#a8458c`},pink:{400:`#ec4d63`,600:`#d42054`,M400:`#d57287`,M600:`#b23a5d`},crimson:{400:`#e34f32`,600:`#c72a1c`,M400:`#cc6c5b`,M600:`#b24a3c`},orange:{400:`#de701d`,600:`#bf5000`,M400:`#d4772c`,M600:`#b35827`},lemon:{400:`#ffd424`,600:`#ffbb10`,M400:`#e7a500`,M600:`#c38f00`},lime:{400:`#43b324`,600:`#2e8200`,M400:`#519e2d`,M600:`#47782c`},mint:{400:`#00a656`,600:`#058541`,M400:`#299c66`,M600:`#2e8057`},teal:{400:`#02a191`,600:`#028079`,M400:`#2d9e8f`,M600:`#3c7873`},azure:{400:`#3091ec`,600:`#1371d6`,M400:`#5f8dcf`,M600:`#3a70b2`},royal:{400:`#5d7df5`,600:`#3353e2`,M400:`#7986d8`,M600:`#4b61c3`},purple:{400:`#b552e2`,600:`#6a27b8`,M400:`#b072cc`,M600:`#9358b0`}},D=y(m()),ee=(e,n,r)=>{if(n!==r){let i=Math.abs(n-r)/100*.05;return n>r?c(i,e):t(i,e)}return e},O=new WeakMap,k={colors:0,palette:0};O.set(p.colors,k.colors),O.set(p.palette,k.palette);var te=({hue:e,shade:t,theme:n,transparency:r})=>{let i=`${typeof e==`object`?JSON.stringify(e):e}`;if(t!==void 0&&(i+=`,${t}`),n!==void 0){let e;n.colors&&(e=O.get(n.colors),e===void 0&&(e=++k.colors,O.set(n.colors,e)));let t;n.palette&&(t=O.get(n.palette),t===void 0&&(t=++k.palette,O.set(n.palette,t))),i+=`,{${e},${t}}`}return r!==void 0&&(i+=`,${r}`),i},A=(0,D.default)((e,t=600,n,r)=>{let i;if(isNaN(t))return;let a={background:E.white,foreground:E.grey[800],...n&&n.palette?{...n.palette,...E}:{...p.palette,...E}},o=n&&n.colors?n.colors:p.colors,s;if(s=typeof e==`string`&&o[e]||e,Object.prototype.hasOwnProperty.call(a,s)&&(s=a[s]),typeof s==`object`){if(i=s[t],!i){let e=Object.keys(s).map(e=>parseInt(e,10)).reduce((e,n)=>Math.abs(n-t)<Math.abs(e-t)?n:e);i=ee(s[e],t,e)}}else i=ee(s,t,600);return r&&(i=_(i,r)),i},(e,t,n,r)=>te({hue:e,shade:t,theme:n,transparency:r})),ne=({boxShadow:e,inset:t=!1,color:n={variable:`border.primaryEmphasis`},shadowWidth:r=`md`,spacerColor:i={variable:`background.default`},spacerWidth:a=`xs`,theme:o=p,...s})=>{let c=s,l=c.hue?A(c.hue,c.shade,o):d({...n,theme:o}),u=o.shadows[r](l);if(a===null)return`${t?`inset`:``} ${u}`;let f=c.spacerHue?A(c.spacerHue,c.spacerShade,o):d({...i,theme:o}),m=`
    ${t?`inset`:``} ${o.shadows[a](f)},
    ${t?`inset`:``} ${u}`;return e?`${m}, ${e}`:m};function j(e,t){let[n,r]=h(e.toString()),[i,a]=h(t.toString());if(r&&r!==`px`)throw Error(`Unexpected \`height\` with '${r}' units.`);if(a&&a!==`px`)throw Error(`Unexpected \`fontSize\` with '${a}' units.`);return n/i}var M=y(b()),re=(e,t,n,r,i=!0)=>{let a=i?t[n]:void 0;return(0,M.useMemo)(()=>{if(i){if(n===`children`)throw Error("Error: `children` is not a valid `useText` prop.");if(a===null||a===``)throw Error(e.displayName?`Error: you must provide a valid \`${n}\` text value for <${e.displayName}>.`:`Error: you must provide a valid \`${n}\` text value.`);if(a===void 0)return r}return a},[e.displayName,a,n,r,i])},N=`&:focus-visible`,P=({condition:e=!0,selector:t=N,shadowWidth:n=`md`,spacerWidth:r=`xs`,styles:{boxShadow:i,...a}={},theme:o,...s})=>{let c=e?ne({boxShadow:i,shadowWidth:n,spacerWidth:r,theme:o,...s}):i,d,f;return r===null?d=o.shadowWidths[n]:(d=`${l(`${o.shadowWidths[n]} - ${o.shadowWidths[r]}`)} solid transparent`,f=o.shadowWidths[r]),u([`&:focus{outline:none;}`,`{outline:`,`;outline-offset:`,`;box-shadow:`,`;`,`}`],t,d,f,c,a)},ie=e(({children:e,theme:t,...n})=>(0,M.cloneElement)(M.Children.only(e),n)).withConfig({displayName:`StyledBaseIcon`,componentId:`sc-1moykgb-0`})([``]);o([`0%{transform:translate(0,5px);}3%{transform:translate(1px,-5px);}6%{transform:translate(3px,-15px);}8%{transform:translate(5px,-18px);}9%{transform:translate(7px,-21px);}11%{transform:translate(8px,-22px);}13%{transform:translate(9px,-23px);}16%{transform:translate(12px,-25px);}18%{transform:translate(13px,-26px);}23%{transform:translate(18px,-26px);}24%{transform:translate(19px,-25px);}28%{transform:translate(22px,-23px);}31%{transform:translate(24px,-21px);}33%{transform:translate(26px,-18px);}34%{transform:translate(28px,-14px);}36%{transform:translate(29px,-12px);}38%{transform:translate(30px,-5px);}39%{transform:translate(31px,5px);}54%{transform:translate(31px,3px);}59%{transform:translate(33px);}61%{transform:translate(43px);}63%{transform:translate(48px);}64%{transform:translate(51px);}66%{transform:translate(53px);}68%{transform:translate(55px);}69%{transform:translate(57px);}76%{transform:translate(60px);}81%{transform:translate(61px);}83%,100%{transform:translate(62px);}`]),o([`4%{transform:translate(0);}6%{transform:translate(-1px);}8%{transform:translate(-2px);}9%{transform:translate(-5px);}11%{transform:translate(-7px);}13%{transform:translate(-12px);}14%{transform:translate(-17px);}16%{transform:translate(-19px);}18%{transform:translate(-22px);}19%{transform:translate(-25px);}21%{transform:translate(-26px);}23%{transform:translate(-27px);}24%{transform:translate(-28px);}26%{transform:translate(-29px);}29%{transform:translate(-30px);}33%,89%{transform:translate(-31px);}91%{transform:translate(-31px,1px);}94%{transform:translate(-31px,2px);}98%{transform:translate(-31px,3px);}99%{transform:translate(-31px,4px);}100%{transform:translate(-31px,5px);}`]),o([`39%{transform:translate(0);}44%{transform:translate(0,1px);}46%{transform:translate(0,2px);}48%{transform:translate(0,3px);}49%{transform:translate(0,4px);}51%{transform:translate(0,5px);}53%{transform:translate(-1px,-6px);}54%{transform:translate(-2px,-13px);}56%{transform:translate(-3px,-15px);}58%{transform:translate(-5px,-19px);}59%{transform:translate(-7px,-21px);}61%{transform:translate(-8px,-22px);}63%{transform:translate(-9px,-24px);}64%{transform:translate(-11px,-25px);}66%{transform:translate(-12px,-26px);}74%{transform:translate(-19px,-26px);}76%{transform:translate(-20px,-25px);}78%{transform:translate(-22px,-24px);}81%{transform:translate(-24px,-21px);}83%{transform:translate(-26px,-19px);}84%{transform:translate(-28px,-15px);}86%{transform:translate(-29px,-13px);}88%{transform:translate(-30px,-6px);}89%{transform:translate(-31px,5px);}91%{transform:translate(-31px,4px);}93%{transform:translate(-31px,3px);}94%{transform:translate(-31px,2px);}98%{transform:translate(-31px,1px);}100%{transform:translate(-31px);}`]);var ae=o([`0%{visibility:hidden;}1%{visibility:visible;}100%{visibility:visible;}`]),oe=e.div.attrs({"data-garden-id":`loaders.loading_placeholder`,"data-garden-version":`9.12.5`,role:`progressbar`}).withConfig({displayName:`StyledLoadingPlaceholder`,componentId:`sc-x3bwsx-0`})([`display:inline-block;`,`;`,``],({$width:e=`1em`,$height:t=`0.9em`,$fontSize:n})=>{let[r,i]=h(n),a;return a=i===void 0?n:`${r}${i===``?`px`:i}`,u([`width:`,`;height:`,`;font-size:`,`;`],e,t,a)},T),se=e.circle.attrs(e=>({cx:40,cy:40,r:34,fill:`none`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:e.$strokeWidthValue,strokeDasharray:`${e.$dasharrayValue} 250`,transform:e.transform})).withConfig({displayName:`StyledSpinnerCircle`,componentId:`sc-o4kd70-0`})([``]),ce=e.svg.attrs(e=>({"data-garden-version":`9.12.5`,xmlns:`http://www.w3.org/2000/svg`,focusable:`false`,viewBox:`0 0 ${e.$width} ${e.$height}`,role:`img`})).withConfig({displayName:`StyledSVG`,componentId:`sc-1xtc3kx-0`})([``,`;`,`;`,`;`,`;`],({$containerWidth:e=`1em`,$containerHeight:t=`0.9em`,$fontSize:n=`inherit`})=>{let[r,i]=h(n),a;return a=i===void 0?n:`${r}${i===``?`px`:i}`,u([`width:`,`;height:`,`;font-size:`,`;`],e,t,a)},({theme:e,$color:t=`inherit`})=>u([`color:`,`;`],d(t.includes(`.`)?{variable:t,theme:e}:{hue:t,theme:e})),T,({$delayShow:e})=>{if(e&&e!==0)return u([`animation:`,` 1ms `,`ms linear 1 forwards;visibility:hidden;`],ae,e)}),F=y(C()),le=function(e){let{duration:t=1250,delayMS:n=750,loop:r=!0}=e===void 0?{}:e,[i,a]=(0,M.useState)(0),[o,s]=(0,M.useState)(!1);return(0,M.useLayoutEffect)(()=>{let e,i,o,c=!1,l=()=>{c||(e=requestAnimationFrame(u))},u=()=>{a(Date.now()-i),l()},d=()=>{c||(o=setTimeout(()=>{cancelAnimationFrame(e),a(Date.now()-i),r&&d()},t),i=Date.now(),s(!0),l())},f=setTimeout(d,n);return()=>{c=!0,clearTimeout(f),clearTimeout(o),cancelAnimationFrame(e)}},[t,n,r]),{elapsed:Math.min(1,i/t),delayMS:n,delayComplete:o}},ue=e=>{let{children:t,render:n=t,...r}=e;return M.createElement(M.Fragment,null,n(le(r)))};ue.defaultProps={duration:1250,delayMS:750,loop:!0},ue.propTypes={children:F.default.func,render:F.default.func,duration:F.default.number,loop:F.default.bool,delayMS:F.default.number};var de={0:6,14:5,26:4,36:3,46:2,58:3,70:4,80:5,91:6},fe={0:-90,8:-81,36:-30,41:-18,44:-8,48:0,55:22,63:53,64:62,66:67,68:78,69:90,71:99,73:112,74:129,76:138,78:159,79:180,81:190,83:207,84:221,86:226,88:235,90:243,99:270},pe={0:0,13:2,26:13,53:86,58:90,63:89,64:88,66:86,68:83,69:81,71:76,73:70,74:62,76:58,78:47,79:37,81:31,83:23,84:16,88:10,89:7,98:1,99:0},me=`loaders.spinner`,he=100,ge=(e,t)=>Object.entries(e).reduce((e,n,r,i)=>{let[a,o]=n,[s,c]=i[r+1]||[he,i[0][1]],l=parseInt(s,10)-parseInt(a,10),u=t/(he-1)*l,d=o;e[a]=o;for(let n=0;n<l;n++)d+=(c-d)*(16.666666666666668/u),u=t/(he-1)*(l-n),e[parseInt(a,10)+n+1]=d;return e[s]=c,e},{}),I=(0,M.forwardRef)(({size:e=`inherit`,duration:t=1250,color:n=`inherit`,delayMS:r=750,...i},a)=>{let o=ge(de,t),s=ge(fe,t),c=ge(pe,t),{elapsed:l,delayComplete:u}=le({duration:t,delayMS:r}),d=(l*100).toFixed(0),f=o[d],p=s[d],m=c[d];return!u&&r!==0?M.createElement(oe,{$width:`1em`,$height:`1em`,$fontSize:e},`\xA0`):M.createElement(ce,Object.assign({$color:n,$containerHeight:`1em`,$containerWidth:`1em`,$fontSize:e,"data-garden-id":me,$height:80,ref:a,$width:80},i),M.createElement(se,{$dasharrayValue:m,$strokeWidthValue:f,transform:`rotate(${p}, ${80/2}, ${80/2})`}))});I.displayName=`Spinner`,I.propTypes={size:F.default.any,duration:F.default.number,color:F.default.string,delayMS:F.default.number};var _e=v(),L=g(),ve=(0,M.createContext)(null),ye=({client:e,children:t})=>(0,L.jsx)(ve.Provider,{value:e,children:t}),be=()=>{let e=(0,M.useContext)(ve);if(!e)throw Error(`useClient must be used within a ClientProvider`);return e};function xe(e){return t=>{e.forEach(e=>{typeof e==`function`?e(t):e!=null&&(e.current=t)})}}var Se=e.div.attrs({"data-garden-id":`tabs.tab`,"data-garden-version":`9.12.6`}).withConfig({displayName:`StyledTab`,componentId:`sc-x2pbow-0`})([`display:`,`;position:relative;transition:color 0.25s ease-in-out;border-bottom:`,`;border-`,`:`,`;cursor:pointer;overflow:hidden;vertical-align:top;user-select:none;text-align:`,`;text-decoration:none;text-overflow:ellipsis;`,`;`,`;&:focus{text-decoration:none;}&::before{transition:box-shadow 0.1s ease-in-out;content:'';}&:focus-visible::before{position:absolute;top:`,`px;right:`,`px;left:`,`px;border-radius:`,`;pointer-events:none;}&:active::before{box-shadow:none;}&[aria-disabled='true']{cursor:default;}`,`;`],e=>e.$isVertical?`block`:`inline-block`,e=>e.$isVertical?void 0:e.theme.borderStyles.solid,e=>e.theme.rtl?`right`:`left`,e=>e.$isVertical?e.theme.borderStyles.solid:void 0,e=>e.$isVertical?e.theme.rtl?`right`:`left`:`center`,({theme:e,$isVertical:t})=>{let n=e.borderWidths.md,r=`calc(100% - ${e.space.base*(t?2:4)}px);`,a,o;if(t)a=`${e.space.base*5}px`,o=`${e.space.base}px ${e.space.base*2}px`;else{let t=e.space.base*2.5;o=`${t}px ${e.space.base*7}px ${t-i(e.borderWidths.md)-i(e.borderWidths.sm)}px`}return u([`margin-bottom:`,`;border-width:`,`;padding:`,`;&:focus-visible::before,&[data-garden-focus-visible]::before{height:`,`;}&:last-of-type{margin-bottom:0;}`],a,n,o,r)},({theme:e,$isSelected:t})=>{let n=t?d({theme:e,variable:`border.primaryEmphasis`}):`transparent`,r=d({theme:e,variable:`foreground.primary`}),i=t?r:`inherit`,a=d({theme:e,variable:`foreground.disabled`});return u([`border-color:`,`;color:`,`;&:hover{color:`,`;}`,` &:active{border-color:currentcolor;color:`,`;}&[aria-disabled='true']{border-color:transparent;color:`,`;}`],n,i,r,P({theme:e,inset:!0,spacerWidth:null,shadowWidth:`sm`,selector:`&:focus-visible::before`,styles:{color:r}}),r,a)},e=>e.theme.space.base*(e.$isVertical?1:2.5),e=>e.theme.space.base*(e.$isVertical?1:6),e=>e.theme.space.base*(e.$isVertical?1:6),e=>e.theme.borderRadii.md,T),Ce=e.div.attrs({"data-garden-id":`tabs.tablist`,"data-garden-version":`9.12.6`}).withConfig({displayName:`StyledTabList`,componentId:`sc-wa5aaj-0`})([`display:`,`;border-bottom:`,`;vertical-align:`,`;white-space:nowrap;`,`;`,`;`,`;`],e=>e.$isVertical?`table-cell`:`block`,e=>e.$isVertical?`none`:e.theme.borderStyles.solid,e=>e.$isVertical?`top`:void 0,({theme:e,$isVertical:t})=>{let n=t?0:`${e.space.base*5}px`,r=t?void 0:e.borderWidths.sm,i=e.fontSizes.md;return u([`margin-top:0;margin-bottom:`,`;border-bottom-width:`,`;padding:0;line-height:`,`;font-size:`,`;`],n,r,j(e.space.base*5,i),i)},({theme:e})=>u([`transition:border-color 0.25s ease-in-out;color-scheme:only `,`;border-bottom-color:`,`;color:`,`;`],e=>e.theme.colors.base,d({theme:e,variable:`border.default`}),d({theme:e,variable:`foreground.default`})),T),we=e.div.attrs({"data-garden-id":`tabs.tabpanel`,"data-garden-version":`9.12.6`}).withConfig({displayName:`StyledTabPanel`,componentId:`sc-7lhrmp-0`})([`display:block;vertical-align:`,`;color-scheme:only `,`;`,`;&[aria-hidden='true']{display:none;}`,`;`],e=>e.$isVertical&&`top`,e=>e.theme.colors.base,({theme:e,$isVertical:t})=>{let n=t?`${e.space.base*8}px`:void 0;return u([`margin-`,`:`,`;`],e.rtl?`right`:`left`,n)},T),Te=e.div.attrs({"data-garden-id":`tabs.tabs`,"data-garden-version":`9.12.6`}).withConfig({displayName:`StyledTabs`,componentId:`sc-1qaor65-0`})([`display:`,`;overflow:hidden;direction:`,`;`,`;`],e=>e.$isVertical?`table`:`block`,e=>e.theme.rtl&&`rtl`,T),Ee=(0,M.createContext)(void 0),De=()=>(0,M.useContext)(Ee),Oe=M.forwardRef(({disabled:e,item:t,...n},r)=>{let i=De();if(e||!i)return M.createElement(Se,Object.assign({role:`tab`,"aria-disabled":e,ref:r,$isVertical:i?.isVertical},n));let{ref:a,...o}=i.getTabProps({value:t});return M.createElement(Se,Object.assign({$isSelected:t===i.selectedValue,$isVertical:i.isVertical},o,n,{ref:xe([a,r])}))});Oe.displayName=`Tabs.Tab`,Oe.propTypes={disabled:F.default.bool,item:F.default.any};var ke=M.forwardRef((e,t)=>{let n=De();if(!n)return M.createElement(Ce,Object.assign({ref:t},e));let r=n.getTabListProps();return M.createElement(Ce,Object.assign({$isVertical:n.isVertical},r,e,{ref:t}))});ke.displayName=`Tabs.TabList`;var Ae=M.forwardRef(({item:e,...t},n)=>{let r=De();if(!r)return M.createElement(we,Object.assign({ref:n},t));let i=r.getTabPanelProps({value:e});return M.createElement(we,Object.assign({"aria-hidden":r.selectedValue!==e,$isVertical:r.isVertical},i,t,{ref:n}))});Ae.displayName=`Tabs.TabPanel`,Ae.propTypes={item:F.default.any};function je(){return!!(typeof window<`u`&&window.document&&window.document.createElement)}var Me=je()?M.useLayoutEffect:M.useEffect,Ne=!1,Pe=0;function Fe(){return++Pe}var Ie=M.useId;function Le(e){if(Ie!==void 0){let t=Ie();return e??t}let t=e??(Ne?Fe():null),[n,r]=M.useState(t);return Me(()=>{n===null&&r(Fe())},[]),M.useEffect(()=>{Ne===!1&&(Ne=!0)},[]),e??n??void 0}function R(...e){return(t,...n)=>e.some(e=>(e&&e(t,...n),t&&t.defaultPrevented))}function Re(...e){for(let t of e)if(t!==void 0)return t}var z={ALT:`Alt`,ASTERISK:`*`,BACKSPACE:`Backspace`,COMMA:`,`,DELETE:`Delete`,DOWN:`ArrowDown`,END:`End`,ENTER:`Enter`,ESCAPE:`Escape`,HOME:`Home`,LEFT:`ArrowLeft`,NUMPAD_ADD:`Add`,NUMPAD_DECIMAL:`Decimal`,NUMPAD_DIVIDE:`Divide`,NUMPAD_ENTER:`Enter`,NUMPAD_MULTIPLY:`Multiply`,NUMPAD_SUBTRACT:`Subtract`,PAGE_DOWN:`PageDown`,PAGE_UP:`PageUp`,PERIOD:`.`,RIGHT:`ArrowRight`,SHIFT:`Shift`,SPACE:` `,TAB:`Tab`,UNIDENTIFIED:`Unidentified`,UP:`ArrowUp`},ze=0,Be=e=>{let t=Le(e);return t=t==null?`id:${ze++}`:`${t}`,t},Ve=(e,t)=>{switch(t.type){case`END`:case`HOME`:case`FOCUS`:case`INCREMENT`:case`DECREMENT`:return{...e,focusedValue:t.payload};case`MOUSE_SELECT`:return{...e,selectedValue:t.payload,focusedValue:void 0};case`KEYBOARD_SELECT`:return{...e,selectedValue:t.payload};case`EXIT_WIDGET`:return{...e,focusedValue:void 0};default:return e}},He=({values:e,direction:t=`horizontal`,defaultFocusedValue:n=e[0],defaultSelectedValue:r,rtl:i,selectedValue:a,focusedValue:o,allowDefaultOnSelect:s=!1,onSelect:c,onFocus:l})=>{let u=a!==void 0,d=o!==void 0,f=(0,M.useMemo)(()=>e.reduce((e,t)=>(e[t]=(0,M.createRef)(),e),{}),[e]),[p,m]=(0,M.useReducer)(Ve,{selectedValue:a,focusedValue:o}),h=Re(o,p.focusedValue),g=Re(a,p.selectedValue);return(0,M.useEffect)(()=>{if(h!==void 0){let e=f[h];e?.current&&e.current.focus()}},[h]),(0,M.useEffect)(()=>{a===void 0&&r!==void 0&&(c&&c(r),u||m({type:`KEYBOARD_SELECT`,payload:r}))},[]),{focusedValue:h,selectedValue:g,getElementProps:({selectedAriaKey:r=`aria-selected`,onFocus:a,onKeyDown:_,onClick:v,value:y,...b})=>{let x=g===y,S=(h===void 0?x:h===y)||g===void 0&&h===void 0&&y===n?0:-1,C=t===`vertical`||t===`both`,w=t===`horizontal`||t===`both`,T=()=>{l&&l(y),!d&&m({type:`FOCUS`,payload:y})},E=()=>{c&&c(y),l&&l(y),!u&&m({type:`MOUSE_SELECT`,payload:y})},D=t=>{let n,r;r=d?e.find(e=>o===e):e.find(e=>p.focusedValue===e);let a=()=>{n=e[e.indexOf(r)+1],n||=e[0],!d&&m({type:`INCREMENT`,payload:n}),l&&l(n)},f=()=>{n=e[e.indexOf(r)-1],n||=e[e.length-1],!d&&m({type:`DECREMENT`,payload:n}),l&&l(n)};if(!(t.ctrlKey||t.metaKey||t.shiftKey||t.altKey))if(t.key===z.UP&&C||t.key===z.LEFT&&w)i&&w?a():f(),t.preventDefault();else if(t.key===z.DOWN&&C||t.key===z.RIGHT&&w)i&&w?f():a(),t.preventDefault();else if(t.key===z.HOME){let n=e[0];!d&&m({type:`HOME`,payload:n}),l&&l(n),t.preventDefault()}else if(t.key===z.END){let n=e[e.length-1];!d&&m({type:`END`,payload:n}),l&&l(n),t.preventDefault()}else(t.key===z.SPACE||t.key===z.ENTER)&&(c&&c(y),!u&&m({type:`KEYBOARD_SELECT`,payload:y}),!s&&t.preventDefault())},ee=e=>{e.target.tabIndex===0&&(m({type:`EXIT_WIDGET`}),l&&l())};return{tabIndex:S,[r]:r?x:void 0,ref:f[y],onFocus:R(a,T),onClick:R(v,E),onKeyDown:R(_,D),onBlur:ee,...b}},getGroupProps:(0,M.useCallback)(({role:e=`group`,...t}={})=>({role:e===null?void 0:e,"data-garden-container-id":`containers.selection`,"data-garden-container-version":`3.1.5`,...t}),[])}},Ue=({children:e,render:t=e,...n})=>M.createElement(M.Fragment,null,t(He(n)));Ue.defaultProps={direction:`horizontal`},Ue.propTypes={children:F.default.func,render:F.default.func,values:F.default.arrayOf(F.default.any).isRequired,rtl:F.default.bool,direction:F.default.oneOf([`horizontal`,`vertical`,`both`]),defaultFocusedValue:F.default.string,defaultSelectedValue:F.default.string,focusedValue:F.default.any,selectedValue:F.default.any,onSelect:F.default.func,onFocus:F.default.func};var We=({tabs:e,orientation:t=`horizontal`,idPrefix:n,...r})=>{let i=Be(n),a=`${i}__panel`,o=`${i}__tab`,s=(0,M.useMemo)(()=>e.reduce((e,t)=>(!t.disabled&&e.push(t.value),e),[]),[e]),{selectedValue:c,focusedValue:l,getGroupProps:u,getElementProps:d}=He({values:s,direction:t,defaultSelectedValue:s[0],...r}),f=(0,M.useCallback)(({role:e=`tablist`,...n}={})=>({...u(n),role:e===null?void 0:e,"aria-orientation":t,"data-garden-container-id":`containers.tabs`,"data-garden-container-version":`2.0.17`}),[u,t]),p=(0,M.useCallback)(({role:e=`tab`,value:t,...n})=>{let r=s.indexOf(t)===-1,{onClick:i,onKeyDown:c,onFocus:l,onBlur:u,...f}=d({value:t,role:e===null?void 0:e,...n});return{...f,onClick:r?void 0:i,onFocus:r?void 0:l,onKeyDown:r?void 0:c,onBlur:r?void 0:u,id:`${o}:${t}`,"aria-disabled":r||void 0,"aria-controls":`${a}:${t}`}},[d,s,a,o]),m=(0,M.useCallback)(({role:e=`tabpanel`,value:t,...n})=>({role:e===null?void 0:e,id:`${a}:${t}`,hidden:t!==c,"aria-labelledby":`${o}:${t}`,...n}),[c,a,o]);return(0,M.useMemo)(()=>({selectedValue:c,focusedValue:l,getTabListProps:f,getTabProps:p,getTabPanelProps:m}),[c,l,f,p,m])},Ge=({children:e,render:t=e,...n})=>M.createElement(M.Fragment,null,t(We(n)));Ge.defaultProps={orientation:`horizontal`},Ge.propTypes={children:F.default.func,render:F.default.func,tabs:F.default.arrayOf(F.default.any).isRequired,rtl:F.default.bool,orientation:F.default.oneOf([`horizontal`,`vertical`]),idPrefix:F.default.string,defaultSelectedValue:F.default.any,selectedValue:F.default.any,onSelect:F.default.func};var Ke=e=>M.Children.toArray(e).reduce((e,t)=>{let n=e;if((0,M.isValidElement)(t))if(`item`in t.props){let e=t.props;n.push({value:e.item,disabled:e.disabled})}else{let e=Ke(t.props.children);n.push(...e)}return n},[]),qe=(0,M.forwardRef)(({isVertical:e=!1,children:t,onChange:n,selectedItem:r,...i},a)=>{let o=(0,M.useContext)(s)||p,[c,l]=(0,M.useState)(),u=Re(r,c),d=(0,M.useMemo)(()=>Ke(t),[t]),f=We({tabs:d,rtl:o.rtl,orientation:e?`vertical`:`horizontal`,selectedValue:u,defaultSelectedValue:d.find(e=>!e.disabled)?.value,onSelect:e=>{n?n(e):l(e)}}),m=(0,M.useMemo)(()=>({isVertical:e,...f}),[e,f]);return M.createElement(Ee.Provider,{value:m},M.createElement(Te,Object.assign({$isVertical:e},i,{ref:a}),t))});qe.propTypes={isVertical:F.default.bool,selectedItem:F.default.any,onChange:F.default.func},qe.displayName=`Tabs`;var B=qe;B.Tab=Oe,B.TabList=ke,B.TabPanel=Ae;var Je=`data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='16'%20height='16'%20focusable='false'%20viewBox='0%200%2016%2016'%3e%3cpath%20fill='none'%20stroke='currentColor'%20d='M13.17%203.07l-1.64.71c-.48-.4-1.03-.72-1.63-.94l-.22-1.79a.511.511%200%2000-.4-.44C8.86.54%208.44.5%208%20.5c-.44%200-.86.04-1.28.11-.22.04-.38.22-.4.44l-.21%201.79c-.6.22-1.15.54-1.63.94l-1.65-.71a.491.491%200%2000-.58.13c-.55.65-.99%201.4-1.29%202.21-.08.21%200%20.44.18.58l1.45%201.08a4.91%204.91%200%20000%201.87l-1.45%201.08c-.18.13-.25.37-.18.58.3.81.74%201.55%201.28%202.2.14.17.38.22.58.13l1.65-.71c.48.4%201.03.72%201.63.94l.21%201.79c.03.22.19.4.4.44.43.07.85.11%201.29.11.44%200%20.86-.04%201.28-.11.22-.04.38-.22.4-.44l.21-1.79c.6-.22%201.15-.54%201.63-.94l1.65.71c.2.09.44.04.58-.13.54-.65.98-1.39%201.28-2.2.08-.21%200-.44-.18-.57L13.4%208.95c.07-.32.1-.63.1-.95s-.03-.63-.09-.94l1.45-1.08c.18-.13.25-.37.18-.58-.3-.81-.74-1.55-1.28-2.2a.51.51%200%2000-.59-.13z'/%3e%3ccircle%20cx='8'%20cy='8'%20r='2.5'%20fill='none'%20stroke='currentColor'/%3e%3c/svg%3e`,Ye=async e=>(await e.get(`currentUser`)).currentUser.role===`admin`,V=async(e,t=!1)=>{try{let n=null;if(!t&&(n=tt(`brandMappings`),n!=null&&n.length!==0))return n;let r=await Qe(e,`/integrations/zendesk/workspace-external-mappings.json`);return await e.request(r)}catch(e){return console.error(`Error in fetch brandmappings:`,e),[]}},Xe=async(e,t)=>{console.log(`saving...`);try{let n=t.map(async t=>{let n=`POST`,r=`/integrations/zendesk/workspace-external-mappings.json`;t.id&&(n=`PUT`,r=`/integrations/zendesk/workspace-external-mappings/${t.id}.json`),console.log(`entered.`,n);let i={workspace_external_mapping:t},a=await Qe(e,r,n);return a.data=JSON.stringify(i),a.httpCompleteResponse=!0,e.request(a).then(e=>{if(e.status>=400)throw Error(`Request failed: ${r}`);return e.responseJSON})});return await Promise.all(n)}catch(e){throw Error(`Failed to save brand mappings: `+e.message)}},Ze=async(e,t)=>{try{let n=`/integrations/zendesk/workspace-external-mappings/${t}.json`,r=await Qe(e,n,`DELETE`);r.httpCompleteResponse=!0;let i=await e.request(r);if(i.status>=400)throw Error(`Request failed: ${n}`);return i.responseJSON}catch(e){throw Error(`Failed to delete brand mapping: `+e.message)}},Qe=async(e,t,n=`GET`)=>{try{let{baseUrl:r}=await H(e);return{url:`${r}${t}`,type:n,contentType:`application/json`,headers:{"ngrok-skip-browser-warning":!0,Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},accepts:`application/json`,secure:!0}}catch(e){console.log(`options error:`,e)}},$e=async(e,t=!1)=>{let n=[];if(!t&&(n=tt(`workspaces`),n!=null&&n.length!==0))return n;let r=await Qe(e,`/integrations/zendesk/workspaces.json`);return await e.request(r)};function et(e,t){window.localStorage.getItem(e)&&window.localStorage.removeItem(e),window.localStorage.setItem(e,JSON.stringify(t))}function tt(e){let t=null;return window.localStorage.getItem(e)&&(t=JSON.parse(window.localStorage.getItem(e))),t}var nt=null,rt=e=>(nt||=Promise.resolve(e.metadata()).then(e=>e.settings),nt),it=e=>e?e.toString().trim().toLowerCase().replace(/^https?:\/\//,``).replace(/\/.*$/,``).replace(/\.prodbench\.com$/,``):``,H=async e=>{let t=it((await rt(e)).subdomain);if(!t)throw Error(`Prodbench account subdomain is not configured`);let n=`${t}.prodbench.com`;return{subdomain:t,baseHost:n,baseUrl:`https://${n}`}},at=async(e,t,n)=>{let{baseUrl:r}=await H(e);return await e.request({url:`${r}/integrations/zendesk/work-items/recommendations.json`,type:`POST`,contentType:`application/json`,headers:{Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},data:JSON.stringify({text:t.subject,short_description:t.description,source:`zd`,brand_id:t.brand.id,source_created_at:ct(t.created_at),filter:{workspace_id:n}}),secure:!0})||[]},ot=async(e,t,n,r)=>{let{baseUrl:i}=await H(e);return await e.request({url:`${i}/integrations/zendesk/work-items/autocomplete.json?q=${t}&workspace_id=${n}&per_page=10`,type:`GET`,contentType:`application/json`,headers:{"ngrok-skip-browser-warning":!0,Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},secure:!0})||[]},st=async(e,t)=>`https://${(await e.get(`currentAccount.subdomain`))[`currentAccount.subdomain`]}.zendesk.com/agent/tickets/${t}`,ct=e=>{if(!e)return null;try{let t=new Date(e);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,`0`)}-${String(t.getDate()).padStart(2,`0`)}`}catch{return e}},lt=e=>{if(!e)return null;try{return new Date(e).toUTCString()}catch{return e}},ut=async(e,t,n)=>{let{baseUrl:r}=await H(e),i=(await e.get(`currentUser`)).currentUser,a=await st(e,t.id),o=[];n&&n.length>0&&(o=await dt(e,r,n));let s=o.map(e=>e.id),c={requester:t.requester,assignee:t.assignee,type:t.type,priority:t.priority,due_by:lt(t.due_by),done_by:{id:i.id,email:i.email,name:i.name}},l=t.description;if(t.comments.length>0){let e=t.comments.length-1;l=t.comments[e].value}let u={case_record:{source_uid:t.id,source_url:a,source_type:`tickets`,title:t.subject||``,description:l||``,source_created_at:lt(t.created_at),additional_source_info:c,attachment_ids:s}},d=await e.request({url:`${r}/integrations/zendesk/case-records.json?brand_id=${t.brand.id}`,type:`POST`,contentType:`application/json`,headers:{Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},data:JSON.stringify(u),secure:!0});return d.workItem||d},dt=async(e,t,n)=>{let r=await e.request({url:`${t}/integrations/zendesk/attachments.json`,type:`POST`,contentType:`application/json`,headers:{Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},data:JSON.stringify({files:n}),secure:!0});return r.attachments||r},ft=async(e,t,n,r)=>{let{baseUrl:i}=await H(e),a=(await e.get(`currentUser`)).currentUser,o=await st(e,t.id),s={requester:t.requester,assignee:t.assignee,type:t.type,priority:t.priority,due_by:lt(t.due_by),done_by:{id:a.id,email:a.email,name:a.name}},c={case_record:{...r?{id:r}:{},source_uid:t.id,source_url:o,source_type:`tickets`,title:t.subject,description:t.description,source_created_at:lt(t.created_at),additional_source_info:s,case_record_work_items_attributes:[{work_item_id:n}]},brand_id:t.brand.id},l=r?`${i}/integrations/zendesk/case-records/${r}.json`:`${i}/integrations/zendesk/case-records.json`;return await e.request({url:l,type:r?`PUT`:`POST`,contentType:`application/json`,headers:{Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},data:JSON.stringify(c),secure:!0})},pt=async(e,t,n,r)=>{let{baseUrl:i}=await H(e),a=(await e.get(`currentUser`)).currentUser,o={brand_id:t.brand.id};return await e.request({url:`${i}/integrations/zendesk/case-records/${r}/work-items/${n}.json?done_by=${a.email}`,type:`DELETE`,contentType:`application/json`,headers:{Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},data:JSON.stringify(o),secure:!0})},mt=e=>typeof e==`string`&&e.trim()||null,ht=e=>mt(e?.source_status)||mt(e?.status?.customer_label)||mt(e?.status?.name)||`Not set`,gt=[`success`,`warning`,`error`,`info`],_t,vt;function yt(){return yt=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},yt.apply(null,arguments)}var bt=function(e){return M.createElement(`svg`,yt({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),_t||=M.createElement(`g`,{fill:`none`,stroke:`currentColor`},M.createElement(`circle`,{cx:7.5,cy:8.5,r:7}),M.createElement(`path`,{strokeLinecap:`round`,d:`M7.5 4.5V9`})),vt||=M.createElement(`circle`,{cx:7.5,cy:12,r:1,fill:`currentColor`}))},xt;function St(){return St=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},St.apply(null,arguments)}var Ct=function(e){return M.createElement(`svg`,St({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),xt||=M.createElement(`g`,{fill:`none`,stroke:`currentColor`},M.createElement(`path`,{strokeLinecap:`round`,strokeLinejoin:`round`,d:`M4 9l2.5 2.5 5-5`}),M.createElement(`circle`,{cx:7.5,cy:8.5,r:7})))},wt,Tt;function Et(){return Et=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},Et.apply(null,arguments)}var Dt=function(e){return M.createElement(`svg`,Et({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),wt||=M.createElement(`path`,{fill:`none`,stroke:`currentColor`,strokeLinecap:`round`,d:`M.88 13.77L7.06 1.86c.19-.36.7-.36.89 0l6.18 11.91c.17.33-.07.73-.44.73H1.32c-.37 0-.61-.4-.44-.73zM7.5 6v3.5`}),Tt||=M.createElement(`circle`,{cx:7.5,cy:12,r:1,fill:`currentColor`}))},Ot,kt;function At(){return At=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},At.apply(null,arguments)}var jt={success:Ct,error:bt,warning:Dt,info:function(e){return M.createElement(`svg`,At({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),Ot||=M.createElement(`g`,{stroke:`currentColor`},M.createElement(`circle`,{cx:7.5,cy:8.5,r:7,fill:`none`}),M.createElement(`path`,{strokeLinecap:`round`,d:`M7.5 12.5V8`})),kt||=M.createElement(`circle`,{cx:7.5,cy:5,r:1,fill:`currentColor`}))}},U={success:`success`,error:`error`,warning:`warning`,info:`info`},Mt=[`small`,`medium`,`large`],Nt=e.div.attrs({"data-garden-id":`buttons.button_group_view`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledSplitButton`,componentId:`sc-1u4v04v-0`})([`display:inline-flex;position:relative;z-index:0;direction:`,`;white-space:nowrap;`,`;`],e=>e.theme.rtl&&`rtl`,T),Pt=`buttons.icon`,Ft=e=>{let t;return e.$position===`start`?t=`margin-${e.theme.rtl?`left`:`right`}`:e.$position===`end`&&(t=`margin-${e.theme.rtl?`right`:`left`}`),t&&u([``,`:`,`px;`],t,e.theme.space.base*2)},W=e(ie).attrs({"data-garden-id":Pt,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledIcon`,componentId:`sc-19meqgg-0`})([`transform:`,`;transition:transform 0.25s ease-in-out,color 0.25s ease-in-out;`,`;`,`;`],e=>e.$isRotated&&`rotate(${e.theme.rtl?`-`:`+`}180deg)`,e=>Ft(e),T),It=e=>e.$isPill?`100px`:e.theme.borderRadii.md,Lt=e=>e.$size===`small`?`${e.theme.space.base*8}px`:e.$size===`large`?`${e.theme.space.base*12}px`:`${e.theme.space.base*10}px`,Rt=({theme:e,$isLink:t,$isBasic:n,$isDanger:r,$isNeutral:i,$isPrimary:a,$focusInset:o})=>{let s,c=d({theme:e,variable:`background.disabled`}),l=d({theme:e,variable:`foreground.disabled`}),f={dark:{offset:-100},light:{offset:100}},p={dark:{offset:-200},light:{offset:200}};if(t){let t={theme:e,variable:r?`foreground.danger`:`foreground.primary`},n=d(t),i=d({...t,...f}),a=d({...t,...p});s=u([`outline-color:transparent;background-color:transparent;color:`,`;`,` &:hover{color:`,`;}&:active,&[aria-pressed='true'],&[aria-pressed='mixed']{color:`,`;}&:disabled{color:`,`;}`],n,P({theme:e,condition:!1,styles:{color:n,outlineColor:d({theme:e,variable:`border.primaryEmphasis`})}}),i,a,l)}else if(a){let t;t=r?`background.dangerEmphasis`:i?`background.emphasis`:`background.primaryEmphasis`;let n={theme:e,variable:t},a=d(n),m=d({...n,...f}),h=d({...n,...p});s=u([`outline-color:transparent;background-color:`,`;color:`,`;&:hover{background-color:`,`;}`,` &:active,&[aria-pressed='true'],&[aria-pressed='mixed']{background-color:`,`;}&:disabled{background-color:`,`;color:`,`;}`],a,d({theme:e,variable:`foreground.onEmphasis`}),m,P({theme:e,inset:o,shadowWidth:o?`sm`:`md`,spacerWidth:o?`sm`:`xs`,styles:(r||i)&&o?{borderColor:d({theme:e,variable:`border.primaryEmphasis`})}:void 0}),h,c,l)}else{let t,a,m,h,g,_;if(r){if(!n){let n={theme:e,variable:`border.dangerEmphasis`};t=d(n),a=d({...n,...f}),m=d({...n,...p}),i&&(h=d(n))}g=`background.dangerEmphasis`,_=i?`foreground.default`:`foreground.danger`}else{if(!n){let n={theme:e,variable:`border.primaryEmphasis`};i?(t=d({theme:e,variable:`border.default`,...f}),a=d(n),h=a,m=d({...n,...f})):(t=d(n),a=d({...n,...f}),m=d({...n,...p}))}g=`background.primaryEmphasis`,_=i?`foreground.default`:`foreground.primary`}let v=d({theme:e,variable:g,transparency:e.opacity[100]}),y=d({theme:e,variable:g,transparency:e.opacity[200]}),b={theme:e,variable:_},x=d(b),S,C,w,T,E;if(i){let t={theme:e,variable:`foreground.subtle`};w=d(t),T=d({...t,...f}),E=d({...t,...p})}else S=d({...b,...f}),C=d({...b,...p});s=u([`outline-color:transparent;border-color:`,`;background-color:transparent;color:`,`;&:hover{border-color:`,`;background-color:`,`;color:`,`;}`,` &:active,&[aria-pressed='true'],&[aria-pressed='mixed']{border-color:`,`;background-color:`,`;color:`,`;}&:disabled{border-color:transparent;background-color:`,`;color:`,`;}& `,`{color:`,`;}&:hover `,`,&:focus-visible `,`{color:`,`;}&:active `,`{color:`,`;}&:disabled `,`{color:`,`;}`],t,x,a,v,S,P({theme:e,inset:o,styles:{borderColor:h}}),m,y,C,c,l,W,w,W,W,T,W,E,W,l)}return s},zt=({theme:e,$isPrimary:t,$isBasic:n,$isPill:r,$focusInset:i})=>{let{rtl:a,borderWidths:o,borders:s}=e,c=a?`right`:`left`,l=a?`left`:`right`,f=o.sm,p=`${t||n?``:`-`}${f}`,m=r&&`-2px`,h=!t&&d({theme:e,variable:`background.disabled`}),g=n?`transparent`:`revert`,_=d({theme:e,variable:`border.primaryEmphasis`}),v=n&&!t&&ne({theme:e,inset:i,spacerColor:{hue:_},color:{hue:`transparent`}});return u([`position:relative;transition:border-color 0.1s ease-in-out,background-color 0.1s ease-in-out,box-shadow 0.1s ease-in-out,color 0.1s ease-in-out,margin-`,` 0.1s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;border:`,` `,`;`,`{border-color:`,`;box-shadow:`,`;}&:hover,&:active,`,`{z-index:1;}&:disabled{z-index:-1;background-color:`,`;}&:not(:first-of-type){margin-`,`:`,`;}&:not(:first-of-type):disabled{margin-`,`:`,`;}&:not(:first-of-type):not(:last-of-type){border-radius:0;}&:first-of-type:not(:last-of-type){border-top-`,`-radius:0;border-bottom-`,`-radius:0;}&:last-of-type:not(:first-of-type){border-top-`,`-radius:0;border-bottom-`,`-radius:0;}&:first-of-type:not(:last-of-type) `,`{margin-`,`:`,`;}&:last-of-type:not(:first-of-type) `,`{margin-`,`:`,`;}`],c,s.sm,g,N,_,v,N,h,c,p,c,f,l,l,c,c,W,l,m,W,c,m)},Bt=e=>{let t=e.$size===`small`?e.theme.iconSizes.sm:e.theme.iconSizes.md;return u([`width:`,`;min-width:`,`;height:`,`;vertical-align:`,`;`],t,t,t,e.$isLink&&`middle`)},Vt=e=>{let t;if(e.$isLink)t=u([`padding:0;font-size:inherit;`]);else{let n=Lt(e),r=l(`${n} - (${e.theme.borderWidths.sm} * 2)`),i,a;e.$size===`small`?(a=e.theme.fontSizes.sm,i=`${e.theme.space.base*3}px`):(a=e.theme.fontSizes.md,i=e.$size===`large`?`${e.theme.space.base*5}px`:`${e.theme.space.base*4}px`),t=u([`padding:0 `,`;height:`,`;line-height:`,`;font-size:`,`;`],f(l(`${i} - ${e.theme.borderWidths.sm}`),a),n,r,a)}return t},Ht=e.button.attrs(e=>({"data-garden-id":e[`data-garden-id`]||`buttons.button`,"data-garden-version":`9.12.5`,type:e.type||`button`})).withConfig({displayName:`StyledButton`,componentId:`sc-qe3ace-0`})([`display:`,`;align-items:`,`;justify-content:`,`;transition:border-color 0.25s ease-in-out,box-shadow 0.1s ease-in-out,background-color 0.25s ease-in-out,color 0.25s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;margin:0;border:`,`;border-radius:`,`;cursor:pointer;width:`,`;overflow:hidden;text-decoration:`,`;text-overflow:ellipsis;white-space:`,`;font-family:inherit;font-weight:`,`;-webkit-font-smoothing:subpixel-antialiased;box-sizing:border-box;user-select:`,`;-webkit-touch-callout:none;`,`;&::-moz-focus-inner{border:0;padding:0;}`,`{text-decoration:none;}&:hover{text-decoration:`,`;}&:active,&[aria-pressed='true'],&[aria-pressed='mixed']{transition:border-color 0.1s ease-in-out,background-color 0.1s ease-in-out,box-shadow 0.1s ease-in-out,color 0.1s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;text-decoration:`,`;}`,`;&:disabled{cursor:default;text-decoration:`,`;}& `,`{`,`}`,` &&{`,`}`,``],e=>e.$isLink?`inline`:`inline-flex`,e=>!e.$isLink&&`center`,e=>!e.$isLink&&`center`,e=>`${e.$isLink?`0px solid`:e.theme.borders.sm} transparent`,e=>It(e),e=>e.$isStretched?`100%`:``,e=>e.$isUnderlined?`underline`:`none`,e=>!e.$isLink&&`nowrap`,e=>e.$isLink?`inherit`:e.theme.fontWeights.regular,e=>!e.$isLink&&`none`,e=>Vt(e),N,e=>e.$isLink?`underline`:`none`,e=>e.$isLink?`underline`:`none`,e=>Rt(e),e=>e.$isLink&&`none`,W,e=>Bt(e),Nt,e=>zt(e),T),Ut=`buttons.icon_button`,Wt=({theme:e})=>{let t={theme:e,variable:`foreground.subtle`};return u([`color:`,`;&:hover{color:`,`;}&:active,&[aria-pressed='true'],&[aria-pressed='mixed']{color:`,`;}`],d(t),d({...t,dark:{offset:-100},light:{offset:100}}),d({...t,dark:{offset:-200},light:{offset:200}}))},Gt=e(Ht).attrs(e=>{let t=e[`data-garden-id`];return{"data-garden-id":t&&t!==`buttons.button`?t:Ut,"data-garden-version":`9.12.5`}}).withConfig({displayName:`StyledIconButton`,componentId:`sc-1t0ughp-0`})([``,`;& `,`{`,`}`,`;`],e=>{let t=Lt(e);return u([`border:`,`;padding:0;width:`,`;min-width:`,`;`,`;&:disabled{background-color:`,`;}`],e.$isBasic&&`none`,t,t,e.$isBasic&&!(e.$isPrimary||e.$isDanger||e.disabled)&&Wt(e),!e.$isPrimary&&`transparent`)},W,e=>{let t=e.theme.iconSizes.md;return u([`width:`,`;height:`,`;& > svg{transition:opacity 0.15s ease-in-out;}`],t,t)},T),Kt=(0,M.createContext)(void 0),qt=()=>(0,M.useContext)(Kt),Jt=(0,M.forwardRef)(({children:e,focusInset:t,isBasic:n=!0,isDanger:r,isNeutral:i,isPill:a=!0,isPrimary:o,isRotated:s,size:c=`medium`,...l},u)=>{let d=qt();return M.createElement(Gt,Object.assign({},l,{$isBasic:n,$isDanger:r,$isNeutral:i,$isPill:a,$isPrimary:o,$size:c,$focusInset:t||d,ref:u}),M.createElement(W,{$isRotated:s},e))});Jt.displayName=`IconButton`,Jt.propTypes={focusInset:F.default.bool,isBasic:F.default.bool,isDanger:F.default.bool,isNeutral:F.default.bool,isPill:F.default.bool,isPrimary:F.default.bool,isRotated:F.default.bool,size:F.default.oneOf(Mt)};var Yt=e(Jt).attrs({"data-garden-id":`notifications.close`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledClose`,componentId:`sc-1mr9nx1-0`})([`position:absolute;top:`,`px;right:`,`;left:`,`;`,` `,`;`],e=>e.theme.space.base,e=>!e.theme.rtl&&`${e.theme.space.base}px`,e=>e.theme.rtl&&`${e.theme.space.base}px`,({theme:e,$type:t})=>{let n;switch(t){case U.warning:n=`foreground.warning`;break;case U.error:n=`foreground.danger`;break;case U.success:n=`foreground.success`;break;default:n=`foreground.subtle`;break}return u([`color:`,`;&:hover{background-color:transparent;color:`,`;}&:active{background-color:transparent;color:`,`;}`],d({variable:n,theme:e}),d({variable:n,light:{offset:100},dark:{offset:-100},theme:e}),d({variable:n,light:{offset:200},dark:{offset:-200},theme:e}))},T),Xt=e.p.attrs({"data-garden-id":`notifications.paragraph`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledParagraph`,componentId:`sc-12tmd6p-0`})([`margin:`,`px 0 0;`,`;`],e=>e.theme.space.base*2,T),Zt=e.div.attrs({"data-garden-id":`notifications.title`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledTitle`,componentId:`sc-xx4jsv-0`})([`margin:0;color:`,`;font-weight:`,`;`,`;`],e=>d({variable:`foreground.default`,theme:e.theme}),e=>e.$isRegular?e.theme.fontWeights.regular:e.theme.fontWeights.semibold,T),Qt=e(e.div.attrs({"data-garden-id":`notifications.base_container`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledBase`,componentId:`sc-14syaqw-0`})([`position:relative;border:`,`;border-radius:`,`;padding:`,`;line-height:`,`;font-size:`,`;direction:`,`;`,`;`,``],e=>e.theme.borders.sm,e=>e.theme.borderRadii.md,e=>{let{space:t}=e.theme;return`${`${t.base*5}px`} ${`${t.base*10}px`}`},e=>j(e.theme.space.base*5,e.theme.fontSizes.md),e=>e.theme.fontSizes.md,e=>e.theme.rtl&&`rtl`,({theme:e,$type:t,$isFloating:n})=>{let{space:r,shadows:i}=e,a,o,s;if(!n&&t&&U[t])switch(t){case U.success:a=`background.success`,o=`border.success`,s=`foreground.success`;break;case U.error:a=`background.danger`,o=`border.danger`,s=`foreground.danger`;break;case U.warning:a=`background.warning`,o=`border.warning`,s=`foreground.warning`;break;case U.info:a=`background.subtle`,o=`border.default`,s=`foreground.subtle`;break}else a=`background.raised`,o=`border.default`,s=`foreground.default`;let c=d({variable:a,theme:e}),l=d({variable:o,theme:e}),f=d({variable:s,theme:e}),p=`${r.base*5}px`,m=`${r.base*7}px`;return u([`border-color:`,`;box-shadow:`,`;background-color:`,`;color:`,`;`],l,n?i.lg(p,m,d({variable:`shadow.large`,theme:e})):void 0,c,f)},T)).attrs({"data-garden-id":`notifications.alert`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledAlert`,componentId:`sc-fyn8jp-0`})([``,` `,`;`],e=>{let{$type:t,theme:n}=e,r;switch(t){case U.success:r=`foreground.successEmphasis`;break;case U.error:r=`foreground.dangerEmphasis`;break;case U.warning:r=`foreground.warningEmphasis`;break;case U.info:r=`foreground.default`;break}return u([``,`{color:`,`;}`],Zt,r?d({variable:r,theme:n}):void 0)},T),$t=e(ie).attrs({"data-garden-id":`notifications.icon`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledIcon`,componentId:`sc-msklws-0`})([`position:absolute;`,` `,` `,``],({theme:{rtl:e,space:t}})=>u([`right:`,`;left:`,`;margin-top:`,`px;`],e&&`${t.base*4}px`,!e&&`${t.base*4}px`,t.base/2),({theme:e,$type:t})=>{let n;switch(t){case U.success:n=`foreground.success`;break;case U.error:n=`foreground.danger`;break;case U.warning:n=`foreground.warning`;break;case U.info:n=`foreground.subtle`;break;default:n=`foreground.default`;break}return u([`color:`,`;`],d({variable:n,theme:e}))},T),en=(0,M.createContext)(void 0),tn=()=>(0,M.useContext)(en),nn=M.forwardRef(({isRegular:e,...t},n)=>M.createElement(Zt,Object.assign({ref:n,$isRegular:e},t)));nn.displayName=`Alert.Title`;var rn=M.forwardRef((e,t)=>M.createElement(Xt,Object.assign({ref:t},e)));rn.displayName=`Alert.Paragraph`;var an;function on(){return on=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},on.apply(null,arguments)}var sn=function(e){return M.createElement(`svg`,on({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),an||=M.createElement(`path`,{stroke:`currentColor`,strokeLinecap:`round`,d:`M3 13L13 3m0 10L3 3`}))},cn=M.forwardRef((e,t)=>{let n=re(cn,e,`aria-label`,`Close`),r=tn();return M.createElement(Yt,Object.assign({ref:t,$type:r,"aria-label":n},e,{focusInset:!0,size:`small`}),M.createElement(sn,null))});cn.displayName=`Alert.Close`;var ln=M.forwardRef(({role:e,type:t,...n},r)=>{let i=jt[t];return M.createElement(en.Provider,{value:t},M.createElement(Qt,Object.assign({ref:r,$type:t,role:e===void 0?`alert`:e},n),M.createElement($t,{$type:t},M.createElement(i,null)),n.children))});ln.displayName=`Alert`,ln.propTypes={type:F.default.oneOf(gt).isRequired};var un=ln;un.Close=cn,un.Paragraph=rn,un.Title=nn;var G=e(un)`
  && {
    padding: 10px 12px 10px 40px;
    border-radius: 10px;
  }
`,K=un.Title,dn=e.div`
  padding: 10px 0;
  border-bottom: 1px solid ${e=>d({theme:e.theme,variable:`border.default`})};

  &:last-child {
    border-bottom: none;
  }

  strong {
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`,fn=e.div`
  font-size: 13px;
  font-weight: 400;
  color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  margin-bottom: 2px;
  line-height: 1.25;
`,pn=e.div`
  font-size: 11px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  display: flex;
  gap: 8px;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: 0;
`;e.div`
  font-size: 11px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  line-height: 1.45;
  margin-bottom: 2px;
  max-height: ${e=>e.isExpanded?`200px`:`0`};
  overflow: hidden;
  opacity: ${e=>e.isExpanded?`1`:`0`};
  transition: all 0.3s ease;
  margin-top: ${e=>e.isExpanded?`8px`:`0`};
`,e.div`
  margin: 4px 0 0;
  padding: 0;
  background: transparent;
  border-radius: 0;
  border: 0;
  display: flex;
  flex-wrap: wrap;
  gap: 6px 12px;
`,e.div`
  display: flex;
  align-items: baseline;
  gap: 4px;
`,e.span`
  font-size: 10px;
  font-weight: 400;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  text-transform: none;
  letter-spacing: 0;
`,e.span`
  font-size: 10px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  word-break: break-word;
`,e.span`
  display: inline-flex;
  align-items: center;
  padding: 3px 9px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 400;
  color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  background: #e3e8ee;
`,e.div`
  display: grid;
  grid-template-columns: minmax(88px, auto) 1fr;
  gap: 6px 10px;
  margin-top: 6px;
`,e.div`
  font-size: 12px;
  font-weight: 400;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
`,e.div`
  font-size: 12px;
  font-weight: 500;
  color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  word-break: break-word;
`,e.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
`,e.button`
  display: inline-flex;
  align-items: center;
  padding: 0;
  border: 0;
  background: transparent;
  color: #1f73b7;
  cursor: pointer;
  font-size: 12px;
  font-weight: 400;
  line-height: 1;

  &:hover:not(:disabled) {
    color: #165e96;
    text-decoration: underline;
  }

  &:disabled {
    opacity: 0.45;
    cursor: default;
  }
`,e.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  padding: 0;
  border: 0;
  background: transparent;
  color: #1f73b7;
  cursor: pointer;

  &:hover {
    color: #165e96;
  }

  &:disabled {
    opacity: 0.45;
    cursor: default;
  }
`,e.div`
  display: flex;
  gap: 8px;
  margin-top: 0;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: wrap;
`,e.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,e.div`
  text-align: center;
  padding: 20px 12px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
`;var mn=e.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px 12px;
  gap: 10px;
  
  p {
    color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  }
`,hn=e.div`
  display: flex;
  flex-direction: column;
  gap: 8px;

  input {
    border-radius: 8px;
  }

  label {
    font-size: 11px;
    font-weight: 400;
  }

  h4 {
    margin-bottom: 12px;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`;e.div`
  h4 {
    margin-bottom: 12px;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`;var gn=e.div`
  padding: 10px 0;
  border-bottom: ${e=>e.$showSeparator?`1px solid ${d({theme:e.theme,variable:`border.default`})}`:`none`};

  strong {
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
  
  p {
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`,_n=e.div`
  font-size: 12px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  line-height: 1.35;
`,vn=e.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: 4px;
  font-size: 11px;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  line-height: 1.35;
`,yn=e.span`
  min-width: 0;
`,bn=e(yn)`
  display: inline-flex;
  align-items: center;
  gap: 4px;
  min-height: 20px;
  padding: 2px 10px;
  border-radius: 999px;
  white-space: nowrap;
  background: ${e=>e.$muted?d({theme:e.theme,variable:`background.subtle`}):`transparent`};
  border: ${e=>e.$muted?`1px solid ${d({theme:e.theme,variable:`border.default`})}`:`0`};
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
  line-height: 1;
`,xn=e.span`
  font-size: 8px;
  line-height: 1;
  text-transform: uppercase;
  vertical-align: super;
  transform: translateY(-2px);
`,Sn=e(yn)`
  flex: 1 1 auto;
  text-align: left;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,Cn=e.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
`,wn=e.span`
  display: inline-block;
  max-width: 100%;
  padding: 3px 9px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  background: ${e=>{let t=e.status?.toLowerCase();return t===`completed`||t===`done`||t===`closed`?`rgba(23, 160, 133, 0.15)`:t===`in progress`||t===`inprogress`||t===`active`?`rgba(236, 150, 0, 0.15)`:t===`open`||t===`reported`?`rgba(30, 115, 190, 0.12)`:d({theme:e.theme,variable:`background.subtle`})}};
  color: ${e=>{let t=e.status?.toLowerCase();return t===`completed`||t===`done`||t===`closed`?`#0f7a63`:t===`in progress`||t===`inprogress`||t===`active`?`#a06000`:t===`open`||t===`reported`?`#1e73be`:d({theme:e.theme,variable:`foreground.default`})}};
`;e.span`
  display: inline-block;
  padding: 3px 9px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 500;
  background: ${e=>{let t=e.priority?.toLowerCase();return t===`high`||t===`urgent`?`rgba(204, 51, 51, 0.12)`:t===`medium`?`rgba(236, 150, 0, 0.15)`:t===`low`?`rgba(30, 115, 190, 0.12)`:d({theme:e.theme,variable:`background.subtle`})}};
  color: ${e=>{let t=e.priority?.toLowerCase();return t===`high`||t===`urgent`?`#cc3333`:t===`medium`?`#a06000`:t===`low`?`#1e73be`:d({theme:e.theme,variable:`foreground.default`})}};
`;var Tn=e.div`
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin: 0px 0;

  button {
    height: 28px;
    min-height: 28px;
    border-radius: 5px;
  }
`;e.div`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
`;var En=e.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: 0;
`,Dn=e(En)`
  flex-wrap: nowrap;
  min-width: 0;
`,On=e(pn)`
  flex: 0 1 auto;
  flex-wrap: nowrap;
  min-width: 0;
  overflow: hidden;
`,kn=e(pn)`
  flex: 1 1 auto;
  flex-wrap: nowrap;
  justify-content: flex-end;
  min-width: 0;
  overflow: hidden;
`,An=e.div`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  white-space: nowrap;
`,jn=e.div`
  margin: 2px 0 8px;
  font-size: 11px;
  font-weight: 400;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: ${e=>d({theme:e.theme,variable:`foreground.subtle`})};
`;function Mn(e){return function(t){e.forEach(function(e){typeof e==`function`?e(t):e!=null&&(e.current=t)})}}var Nn=[`small`,`medium`,`large`],Pn=`buttons.button_group_view`,Fn=e.div.attrs({"data-garden-id":Pn,"data-garden-version":`8.76.9`}).withConfig({displayName:`StyledButtonGroup`,componentId:`sc-1fbpzef-0`})([`display:inline-flex;position:relative;z-index:0;direction:`,`;white-space:nowrap;`,`;`],e=>e.theme.rtl&&`rtl`,e=>w(Pn,e));Fn.defaultProps={theme:p};var In=`buttons.icon`,Ln=e=>{let t;return e.position===`start`?t=`margin-${e.theme.rtl?`left`:`right`}`:e.position===`end`&&(t=`margin-${e.theme.rtl?`right`:`left`}`),t&&u([``,`:`,`px;`],t,e.theme.space.base*2)},q=e(e=>{let{children:t,isRotated:n,theme:r,...i}=e;return M.cloneElement(M.Children.only(t),i)}).attrs({"data-garden-id":In,"data-garden-version":`8.76.9`}).withConfig({displayName:`StyledIcon`,componentId:`sc-19meqgg-0`})([`transform:`,`;transition:transform 0.25s ease-in-out,color 0.25s ease-in-out;`,`;`,`;`],e=>e.isRotated&&`rotate(${e.theme.rtl?`-`:`+`}180deg)`,e=>Ln(e),e=>w(In,e));q.defaultProps={theme:p};var Rn=`buttons.button`,zn=e=>e.isPill?`100px`:e.theme.borderRadii.md,Bn=e=>A(`neutralHue`,200,e.theme),Vn=e=>e.size===`small`?`${e.theme.space.base*8}px`:e.size===`large`?`${e.theme.space.base*12}px`:`${e.theme.space.base*10}px`,Hn=e=>{let t,n;n=e.disabled||e.isNeutral&&(e.isPrimary||e.isSelected)&&!e.isDanger?`neutralHue`:e.isDanger?`dangerHue`:`primaryHue`;let r=A(n,600,e.theme),i=A(n,700,e.theme),a=A(n,800,e.theme),o=A(`primaryHue`,600,e.theme),s=Bn(e),c=A(n,400,e.theme);if(e.isLink)t=u([`outline-color:transparent;background-color:transparent;color:`,`;`,` &:hover{color:`,`;}&:active,&[aria-pressed='true'],&[aria-pressed='mixed']{color:`,`;}&:disabled{color:`,`;}`],r,P({theme:e.theme,condition:!1,styles:{color:r,outlineColor:o}}),i,a,c);else if(e.isPrimary||e.isSelected)t=u([`outline-color:transparent;background-color:`,`;color:`,`;&:hover{background-color:`,`;}`,` &:active{background-color:`,`;}&[aria-pressed='true'],&[aria-pressed='mixed']{background-color:`,`;}&:disabled{background-color:`,`;color:`,`;}`],e.isPrimary&&e.isSelected?a:r,e.theme.palette.white,i,P({theme:e.theme,inset:e.focusInset,shadowWidth:e.focusInset?`sm`:`md`,spacerWidth:e.focusInset?`sm`:`xs`,styles:e.isDanger&&e.focusInset?{borderColor:o}:void 0}),a,e.isPrimary&&a,s,c);else{let n=e.isNeutral&&!e.isDanger?A(`neutralHue`,300,e.theme):r,o=e.isNeutral?A(`foreground`,600,e.theme):r,l=e.isNeutral&&!e.isDanger?r:i,d=e.isNeutral?o:i;t=u([`outline-color:transparent;border-color:`,`;background-color:transparent;color:`,`;&:hover{border-color:`,`;background-color:`,`;color:`,`;}`,` &:active,&[aria-pressed='true'],&[aria-pressed='mixed']{border-color:`,`;background-color:`,`;color:`,`;}&:disabled{border-color:transparent;background-color:`,`;color:`,`;}& `,`{color:`,`;}&:hover `,`,&:focus-visible `,`,&[data-garden-focus-visible] `,`{color:`,`;}&:active `,`{color:`,`;}&:disabled `,`{color:`,`;}`],!e.isBasic&&n,o,!e.isBasic&&l,_(r,.08),d,P({theme:e.theme,inset:e.focusInset,styles:e.isNeutral?{borderColor:r}:void 0}),!e.isBasic&&a,_(r,.2),!e.isNeutral&&a,s,c,q,e.isNeutral&&A(`neutralHue`,600,e.theme),q,q,q,e.isNeutral&&A(`neutralHue`,700,e.theme),q,e.isNeutral&&o,q,c)}return t},Un=e=>{let{theme:t,isPrimary:n,isBasic:r,isSelected:i,isPill:a,focusInset:o}=e,{rtl:s,borderWidths:c,borders:l}=t,d=s?`right`:`left`,f=s?`left`:`right`,p=c.sm,m=`${n||r?``:`-`}${p}`,h=a&&`-2px`,g=!n&&Bn(e),_=r?`transparent`:`revert`,v=A(`primaryHue`,600,t),y=r&&!i&&!n&&ne({theme:t,inset:o,spacerHue:v,hue:`transparent`});return u([`position:relative;transition:border-color 0.1s ease-in-out,background-color 0.1s ease-in-out,box-shadow 0.1s ease-in-out,color 0.1s ease-in-out,margin-`,` 0.1s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;border:`,` `,`;`,`{border-color:`,`;box-shadow:`,`;}&:hover,&:active,`,`{z-index:1;}&:disabled{z-index:-1;background-color:`,`;}&:not(:first-of-type){margin-`,`:`,`;}&:not(:first-of-type):disabled{margin-`,`:`,`;}&:not(:first-of-type):not(:last-of-type){border-radius:0;}&:first-of-type:not(:last-of-type){border-top-`,`-radius:0;border-bottom-`,`-radius:0;}&:last-of-type:not(:first-of-type){border-top-`,`-radius:0;border-bottom-`,`-radius:0;}&:first-of-type:not(:last-of-type) `,`{margin-`,`:`,`;}&:last-of-type:not(:first-of-type) `,`{margin-`,`:`,`;}`],d,l.sm,_,N,v,y,N,g,d,m,d,p,f,f,d,d,q,f,h,q,d,h)},Wn=e=>{let t=e.size===`small`?e.theme.iconSizes.sm:e.theme.iconSizes.md;return u([`width:`,`;min-width:`,`;height:`,`;vertical-align:`,`;`],t,t,t,e.isLink&&`middle`)},Gn=e=>{let t;if(e.isLink)t=u([`padding:0;font-size:inherit;`]);else{let n=Vn(e),r=l(`${n} - (${e.theme.borderWidths.sm} * 2)`),i,a;e.size===`small`?(a=e.theme.fontSizes.sm,i=`${e.theme.space.base*3}px`):(a=e.theme.fontSizes.md,i=e.size===`large`?`${e.theme.space.base*5}px`:`${e.theme.space.base*4}px`),t=u([`padding:0 `,`;height:`,`;line-height:`,`;font-size:`,`;`],f(l(`${i} - ${e.theme.borderWidths.sm}`),a),n,r,a)}return t},Kn=e.button.attrs(e=>({"data-garden-id":Rn,"data-garden-version":`8.76.9`,type:e.type||`button`})).withConfig({displayName:`StyledButton`,componentId:`sc-qe3ace-0`})([`display:`,`;align-items:`,`;justify-content:`,`;transition:border-color 0.25s ease-in-out,box-shadow 0.1s ease-in-out,background-color 0.25s ease-in-out,color 0.25s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;margin:0;border:`,`;border-radius:`,`;cursor:pointer;width:`,`;overflow:hidden;text-decoration:none;text-overflow:ellipsis;white-space:`,`;font-family:inherit;font-weight:`,`;-webkit-font-smoothing:subpixel-antialiased;box-sizing:border-box;user-select:`,`;-webkit-touch-callout:none;`,`;&::-moz-focus-inner{border:0;padding:0;}`,`{text-decoration:none;}&:hover{text-decoration:`,`;}&:active,&[aria-pressed='true'],&[aria-pressed='mixed']{transition:border-color 0.1s ease-in-out,background-color 0.1s ease-in-out,box-shadow 0.1s ease-in-out,color 0.1s ease-in-out,outline-color 0.1s ease-in-out,z-index 0.25s ease-in-out;text-decoration:`,`;}`,`;&:disabled{cursor:default;text-decoration:`,`;}& `,`{`,`}`,` &&{`,`}`,``],e=>e.isLink?`inline`:`inline-flex`,e=>!e.isLink&&`center`,e=>!e.isLink&&`center`,e=>`${e.isLink?`0px solid`:e.theme.borders.sm} transparent`,e=>zn(e),e=>e.isStretched?`100%`:``,e=>!e.isLink&&`nowrap`,e=>e.isLink?`inherit`:e.theme.fontWeights.regular,e=>!e.isLink&&`none`,e=>Gn(e),N,e=>e.isLink?`underline`:`none`,e=>e.isLink?`underline`:`none`,e=>Hn(e),e=>e.isLink&&`none`,q,e=>Wn(e),Fn,e=>Un(e),e=>w(Rn,e));Kn.defaultProps={theme:p};var qn=(0,M.createContext)(void 0),Jn=()=>(0,M.useContext)(qn),Yn=(0,M.createContext)(void 0),Xn=()=>(0,M.useContext)(Yn),Zn=e=>M.createElement(q,Object.assign({position:`start`},e));Zn.displayName=`Button.StartIcon`;var Qn=Zn,$n=e=>M.createElement(q,Object.assign({position:`end`},e));$n.displayName=`Button.EndIcon`;var er=$n,tr=(0,M.forwardRef)((e,t)=>{let n=Jn(),r=Xn(),i=t,a={...e,focusInset:e.focusInset||n!==void 0||r};if(n&&!e.disabled){if(!e.value)throw Error(`"value" prop must be provided to Button when used within a ButtonGroup`);a=n.getButtonProps({isSelected:e.value===n.selectedItem,...a}),i=Mn([a.ref,t])}return M.createElement(Kn,Object.assign({},a,{ref:i}))});tr.displayName=`Button`,tr.propTypes={isNeutral:F.default.bool,isPrimary:F.default.bool,isDanger:F.default.bool,isPill:F.default.bool,isBasic:F.default.bool,focusInset:F.default.bool,isLink:F.default.bool,isStretched:F.default.bool,isSelected:F.default.bool,size:F.default.oneOf(Nn)},tr.defaultProps={size:`medium`};var J=tr;J.EndIcon=er,J.StartIcon=Qn;var nr=`
  min-height: 32px;
  padding: 0 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  box-shadow: none;
`,rr=e(J)`
  ${nr}
  background: #1f73b7;
  border-color: #1f73b7;
  color: #ffffff;

  &:hover:not([disabled]) {
    background: #165e96;
    border-color: #165e96;
    color: #ffffff;
  }
`,ir=e(J)`
  ${nr}
  background: ${e=>d({theme:e.theme,variable:`background.default`})};
  border-color: #1f73b7;
  color: #1f73b7;

  &:hover:not([disabled]) {
    background: #f3f8fc;
    border-color: #165e96;
    color: #165e96;
  }
`,ar=e(J)`
  ${nr}
  min-height: 28px;
  padding: 0 4px;
  background: transparent;
  border-color: transparent;
  color: #1f73b7;

  &:hover:not([disabled]) {
    background: transparent;
    border-color: transparent;
    color: #165e96;
    text-decoration: underline;
  }
`,or=e(ir)`
  height: 24px;
  min-height: 24px;
  padding: 0 8px;
  font-size: 12px;
  background: #ffffff;
`,Y=e(ar)`
  min-height: 26px;
  padding: 0 2px;
  font-size: 12px;
`;e(rr)`
  height: 24px;
  min-height: 24px;
  padding: 0 8px;
  font-size: 12px;
`;var sr=e(e(J)`
  ${nr}
  background: ${e=>d({theme:e.theme,variable:`background.default`})};
  border-color: #d93f4c;
  color: #d93f4c;

  &:hover:not([disabled]) {
    background: #fff5f5;
    border-color: #b52d3a;
    color: #b52d3a;
  }
`)`
  height: 24px;
  min-height: 24px;
  padding: 0 8px;
  font-size: 12px;
  background: #ffffff;

  &:disabled {
    background: transparent;
    border-color: #d93f4c;
    color: #c2c8cc;
  }
`,cr=`720px`,lr=`260px`,ur=`assets/modal.html`,dr=e=>`${ur}?${new URLSearchParams({title:e?.title||`Details`,content:e?.description||`<p>No details available.</p>`}).toString()}`,fr=async(e,t)=>e.invoke(`instances.create`,{location:`modal`,url:dr(t),size:{width:cr,height:lr}}),pr=({ticketData:e,onWorkItemLinked:t})=>{let n=be(),[r,i]=(0,M.useState)(!0),[a,o]=(0,M.useState)(null),[s,c]=(0,M.useState)(null),[l,u]=(0,M.useState)([]);(0,M.useEffect)(()=>{d()},[]);let d=async()=>{try{i(!0),c(null);let t=(await V(n)).find(t=>t.external_uid+``==e.brand.id+``);console.log(t);let r=await at(n,e,t.workspace_id);console.log(`suggests:`,r),u(r||[])}catch(e){c(e.message||`Failed to load suggestions`)}finally{i(!1)}},f=async r=>{try{o(r.id),c(null),await ft(n,e,r.id),t(r)}catch(e){c(e.message||`Failed to link work item`),o(null)}};return r?(0,L.jsx)(mn,{children:(0,L.jsx)(I,{size:`32`})}):s?(0,L.jsxs)(G,{type:`error`,children:[(0,L.jsx)(K,{children:`Error`}),s]}):l.length===0?(0,L.jsx)(G,{type:`info`,children:`No work item suggestions found for this ticket.`}):(0,L.jsxs)(`div`,{children:[(0,L.jsx)(jn,{children:`Suggested fixes`}),l.map(e=>{let t=ht(e);return(0,L.jsxs)(dn,{children:[(0,L.jsx)(fn,{children:e.title}),(0,L.jsxs)(En,{children:[(0,L.jsxs)(pn,{children:[(0,L.jsx)(wn,{status:t,children:t}),(0,L.jsx)(Y,{size:`small`,onClick:()=>fr(n,e),children:`View Details`})]}),(0,L.jsx)(or,{size:`small`,onClick:()=>f(e),disabled:a===e.id,children:a===e.id?`Linking...`:`Link`})]})]},e.id)})]})},mr=({idPrefix:e,hasHint:t,hasMessage:n})=>{let r=Be(e),i=`${r}--input`,a=`${r}--label`,o=`${r}--hint`,s=`${r}--message`,c=(0,M.useCallback)(({id:e=a,htmlFor:t=i,...n}={})=>({"data-garden-container-id":`containers.field.label`,"data-garden-container-version":`3.0.22`,id:e,htmlFor:t,...n}),[a,i]),l=(0,M.useCallback)(({id:e=o,...t}={})=>({"data-garden-container-id":`containers.field.hint`,"data-garden-container-version":`3.0.22`,id:e,...t}),[o]),u=(0,M.useCallback)(({id:e=i,"aria-describedby":r,...c}={})=>({"data-garden-container-id":`containers.field.input`,"data-garden-container-version":`3.0.22`,id:e,"aria-labelledby":a,"aria-describedby":(()=>{if(r)return r;let e=[];return t&&e.push(o),n&&e.push(s),e.length>0?e.join(` `):void 0})(),...c}),[i,a,o,s,t,n]),d=(0,M.useCallback)(({id:e=s,role:t=`alert`,...n}={})=>({"data-garden-container-id":`containers.field.message`,"data-garden-container-version":`3.0.22`,role:t===null?void 0:t,id:e,...n}),[s]);return(0,M.useMemo)(()=>({getLabelProps:c,getHintProps:l,getInputProps:u,getMessageProps:d}),[c,l,u,d])},hr=({children:e,render:t=e,...n})=>M.createElement(M.Fragment,null,t(mr(n)));hr.propTypes={children:F.default.func,render:F.default.func,idPrefix:F.default.string,hasHint:F.default.bool,hasMessage:F.default.bool};var gr=(0,M.createContext)(void 0),_r=()=>(0,M.useContext)(gr),vr=e.div.attrs({"data-garden-id":`forms.field`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledField`,componentId:`sc-12gzfsu-0`})([`position:relative;direction:`,`;margin:0;border:0;padding:0;font-size:0;`,`;`],e=>e.theme.rtl?`rtl`:`ltr`,T),yr=`forms.input_label`,br=e.label.attrs(e=>({"data-garden-id":e[`data-garden-id`]||yr,"data-garden-version":e[`data-garden-version`]||`9.12.5`})).withConfig({displayName:`StyledLabel`,componentId:`sc-2utmsz-0`})([`direction:`,`;vertical-align:middle;line-height:`,`;color:`,`;font-size:`,`;font-weight:`,`;&[hidden]{display:`,`;vertical-align:`,`;text-indent:`,`;font-size:`,`;`,`;}`,`;`],e=>e.theme.rtl&&`rtl`,e=>j(e.theme.space.base*5,e.theme.fontSizes.md),e=>d({theme:e.theme,variable:`foreground.default`}),e=>e.theme.fontSizes.md,e=>e.$isRegular?e.theme.fontWeights.regular:e.theme.fontWeights.semibold,e=>e.$isRadio?`inline-block`:`inline`,e=>e.$isRadio&&`top`,e=>e.$isRadio&&`-100%`,e=>e.$isRadio&&`0`,e=>!e.$isRadio&&r(),T),xr=`forms.input_hint`,Sr=e.div.attrs(e=>({"data-garden-id":e[`data-garden-id`]||xr,"data-garden-version":e[`data-garden-version`]||`9.12.5`})).withConfig({displayName:`StyledHint`,componentId:`sc-17c2wu8-0`})([`direction:`,`;display:block;vertical-align:middle;line-height:`,`;color:`,`;font-size:`,`;`,`;`],e=>e.theme.rtl&&`rtl`,e=>j(e.theme.space.base*5,e.theme.fontSizes.md),e=>d({theme:e.theme,variable:`foreground.subtle`}),e=>e.theme.fontSizes.md,T),Cr=e(ie).attrs({"data-garden-id":`forms.input_message_icon`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledMessageIcon`,componentId:`sc-1ph2gba-0`})([`width:`,`;height:`,`;`,`;`],e=>e.theme.iconSizes.md,e=>e.theme.iconSizes.md,T),wr=`forms.input_message`,X=e.div.attrs(e=>({"data-garden-id":e[`data-garden-id`]||wr,"data-garden-version":e[`data-garden-version`]||`9.12.5`})).withConfig({displayName:`StyledMessage`,componentId:`sc-30hgg7-0`})([`direction:`,`;display:inline-block;position:relative;vertical-align:middle;`,`;`,`;& `,`{position:absolute;top:-1px;`,`:0;}`,`:not([hidden]) + &{display:block;}`,`;`],e=>e.theme.rtl&&`rtl`,({theme:e,$validation:t})=>{let n=e.fontSizes.sm,r=j(e.iconSizes.md,e.fontSizes.sm),i=`${e.space.base}px`,a=t?l(`${e.space.base*2} + ${e.iconSizes.md}`):void 0;return u([`padding-`,`:`,`;line-height:`,`;font-size:`,`;`,`:not([hidden]) + &{margin-top:`,`;}`],e.rtl?`right`:`left`,a,r,n,br,i)},({theme:e,$validation:t})=>{let n;return n=t===`error`?`foreground.danger`:t===`success`?`foreground.success`:t===`warning`?`foreground.warning`:`foreground.subtle`,u([`color:`,`;`],d({theme:e,variable:n}))},Cr,e=>e.theme.rtl?`right`:`left`,br,T),Tr=`forms.input`,Er=e=>e===`warning`||e===`error`,Dr=e.input.attrs(e=>({"data-garden-id":Tr,"data-garden-version":`9.12.5`,"aria-invalid":Er(e.$validation)})).withConfig({displayName:`StyledTextInput`,componentId:`sc-1r6733h-0`})([`appearance:none;transition:border-color 0.25s ease-in-out,box-shadow 0.1s ease-in-out,background-color 0.25s ease-in-out,color 0.25s ease-in-out,z-index 0.25s ease-in-out;direction:`,`;border:`,`;border-radius:`,`;width:100%;box-sizing:border-box;vertical-align:middle;font-family:inherit;&::-ms-browse{border-radius:`,`;}&::-ms-clear,&::-ms-reveal{display:none;}&::-moz-color-swatch{border:none;border-radius:`,`;}&::-webkit-color-swatch{border:none;border-radius:`,`;}&::-webkit-color-swatch-wrapper{padding:0;}&::-webkit-clear-button,&::-webkit-inner-spin-button,&::-webkit-search-cancel-button,&::-webkit-search-results-button{display:none;}&::-webkit-datetime-edit{direction:`,`;line-height:1;}&::-webkit-calendar-picker-indicator{border-radius:100%;}&:invalid{box-shadow:none;}&[type='file']::-ms-value{display:none;}@media screen and (min--moz-device-pixel-ratio:0){&[type='number']{appearance:textfield;}}`,`;`,`;&:disabled{cursor:default;}`,`;`],e=>e.theme.rtl&&`rtl`,e=>e.$isBare?`none`:e.theme.borders.sm,e=>e.$isBare?`0`:e.theme.borderRadii.md,e=>e.theme.borderRadii.sm,e=>e.theme.borderRadii.sm,e=>e.theme.borderRadii.sm,e=>e.theme.rtl&&`rtl`,({theme:e,$isBare:t,$isCompact:n})=>{let r=e.fontSizes.md,i=`${e.space.base*3}px`,a,o,s,c;n?(a=`${e.space.base*8}px`,o=`${e.space.base*1.5}px`,s=l(`${e.fontSizes.sm} - 1`),c=`${e.space.base*6}px`):(a=`${e.space.base*10}px`,o=`${e.space.base*2.5}px`,s=e.fontSizes.sm,c=`${e.space.base*7}px`);let d=l(`${a} - (${o} * 2) - (${e.borderWidths.sm} * 2)`),p=t?`0`:`${f(o,r)} ${f(i,r)}`,m=l(`(${d} - ${c}) / 2`),h=l(`${o} + ${m} - ${i}`),g=`${e.space.base*5}px`,_=e.iconSizes.md;return u([`padding:`,`;min-height:`,`;line-height:`,`;font-size:`,`;&::-ms-browse{font-size:`,`;}&[type='date'],&[type='datetime-local'],&[type='file'],&[type='month'],&[type='time'],&[type='week']{max-height:`,`;}&[type='file']{line-height:1;}@supports (-ms-ime-align:auto){&[type='color']{padding:`,`;}}&::-moz-color-swatch{margin-top:`,`;margin-left:`,`;width:calc(100% + `,`);height:`,`;}&::-webkit-calendar-picker-indicator{background-position:center;background-size:`,`;padding:0;width:`,`;height:`,`;}&::-webkit-color-swatch{margin:`,` `,`;}`,`:not([hidden]) + &&,`,` + &&,`,` + &&,&& + `,`,&& ~ `,`{margin-top:`,`px;}`],p,t?`1em`:a,j(d,r),r,s,a,n?`0 2px`:`1px 3px`,m,h,l(`${h} * -2`),c,_,g,g,m,h,br,Sr,X,Sr,X,e.space.base*(n?1:2))},({theme:e,$isBare:t,$isHovered:n,$focusInset:r,$validation:i})=>{let a=d({theme:e,variable:`foreground.default`}),o=t?`transparent`:d({theme:e,variable:`background.default`}),s,c,l,f;i?(i===`success`?l=`border.successEmphasis`:i===`warning`?l=`border.warningEmphasis`:i===`error`&&(l=`border.dangerEmphasis`),s=d({theme:e,variable:l}),c=s,f=s):(s=d({theme:e,variable:`border.default`,dark:{offset:-100},light:{offset:100}}),l=`border.primaryEmphasis`,c=d({theme:e,variable:l}),f=c);let p=t?void 0:d({theme:e,variable:`background.disabled`}),m=d({theme:e,variable:`border.disabled`}),h=d({theme:e,variable:`foreground.disabled`}),g=h,_=p,v=`
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" focusable="false" viewBox="0 0 16 16" aria-hidden="true" color="${d({theme:e,variable:`foreground.subtle`})}">
      <path fill="currentColor" d="M12.688 5.61a.5.5 0 01.69.718l-.066.062-5 4a.5.5 0 01-.542.054l-.082-.054-5-4a.5.5 0 01.55-.83l.074.05L8 9.359l4.688-3.75z"/>
    </svg>`,y=`url("data:image/svg+xml,${encodeURIComponent(v)}")`;return u([`border-color:`,`;background-color:`,`;color:`,`;&::placeholder{opacity:1;color:`,`;}&::-webkit-datetime-edit{color:`,`;}&::-webkit-calendar-picker-indicator{background-image:`,`;}&[readonly],&[aria-readonly='true']{background-color:`,`;}&:hover{border-color:`,`;}`,` &::-webkit-calendar-picker-indicator:focus-visible{`,`}&:disabled,&[aria-disabled='true']{border-color:`,`;background-color:`,`;color:`,`;}`],n?c:s,o,a,g,g,y,_,c,P({theme:e,inset:r,color:{variable:l},styles:{borderColor:f},condition:!t}),P({theme:e}),m,p,h)},T),Z=e(ie).attrs({"data-garden-id":`forms.media_figure`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledTextMediaFigure`,componentId:`sc-1qepknj-0`})([`transform:`,`;transition:transform 0.25s ease-in-out,color 0.25s ease-in-out;`,`;`,` `,`;`],e=>e.$isRotated&&`rotate(${e.theme.rtl?`-`:`+`}180deg)`,e=>{let t=e.theme.iconSizes.md,n=`1px ${e.theme.space.base*2}px auto 0`,r=`1px 0 auto ${e.theme.space.base*2}px`,i;return i=e.$position===`start`?e.theme.rtl?r:n:e.theme.rtl?n:r,u([`margin:`,`;width:`,`;height:`,`;`],i,t,t)},({theme:e,$isDisabled:t,$isHovered:n,$isFocused:r})=>{let i;if(t)i=d({theme:e,variable:`foreground.disabled`});else{let t={theme:e,variable:`foreground.subtle`};i=d(n||r?{...t,dark:{offset:-100},light:{offset:100}}:t)}return u([`color:`,`;`],i)},T),Or=`forms.faux_input`,kr=e(Dr).attrs(e=>({as:`div`,"aria-readonly":e.$isReadOnly,"aria-disabled":e.$isDisabled,"data-garden-id":Or,"data-garden-version":`9.12.5`})).withConfig({displayName:`StyledTextFauxInput`,componentId:`sc-yqw7j9-0`})([`display:`,`;align-items:`,`;cursor:`,`;overflow:hidden;`,` & > `,`{vertical-align:`,`;`,`{box-shadow:unset;}}& > `,`{flex-shrink:`,`;}`,`;`],e=>e.$mediaLayout?`inline-flex`:`inline-block`,e=>e.$mediaLayout&&`baseline`,e=>e.$mediaLayout&&!e.$isDisabled?`text`:`default`,({theme:e,$validation:t,$focusInset:n,$isBare:r,$isFocused:i})=>{let a,o;return t?(t===`success`?a=`border.successEmphasis`:t===`warning`?a=`border.warningEmphasis`:t===`error`&&(a=`border.dangerEmphasis`),o=d({theme:e,variable:a})):(a=`border.primaryEmphasis`,o=d({theme:e,variable:a})),u([``,``],P({theme:e,inset:n,color:{variable:a},selector:i?`&`:`&:focus-within`,styles:{borderColor:o},condition:!r}))},Dr,e=>!e.$mediaLayout&&`baseline`,N,Z,e=>e.$mediaLayout&&`0`,T),Ar=`forms.radio_label`,jr=e=>{let t=e.theme.space.base*4,n=t+e.theme.space.base*2,r=e.theme.space.base*5;return u([`padding-`,`:`,`px;&[hidden]{padding-`,`:`,`px;line-height:`,`px;}`],e.theme.rtl?`right`:`left`,n,e.theme.rtl?`right`:`left`,t,r)},Q=e(br).attrs({"data-garden-id":Ar,"data-garden-version":`9.12.5`,$isRadio:!0}).withConfig({displayName:`StyledRadioLabel`,componentId:`sc-1aq2e5t-0`})([`display:inline-block;position:relative;cursor:pointer;`,`;`,`;`],e=>jr(e),T),$=e(Q).attrs({"data-garden-id":`forms.checkbox_label`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledCheckLabel`,componentId:`sc-x7nr1-0`})([``,`;`],T),Mr=e(Sr).attrs({"data-garden-id":`forms.radio_hint`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledRadioHint`,componentId:`sc-eo8twg-0`})([`padding-`,`:`,`;`,`;`],e=>e.theme.rtl?`right`:`left`,e=>l(`${e.theme.space.base} * 6px`),T),Nr=e(Mr).attrs({"data-garden-id":`forms.checkbox_hint`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledCheckHint`,componentId:`sc-1kl8e8c-0`})([``,`;`],T),Pr=e.input.attrs({"data-garden-id":`forms.radio`,"data-garden-version":`9.12.5`,type:`radio`}).withConfig({displayName:`StyledRadioInput`,componentId:`sc-qsavpv-0`})([`position:absolute;opacity:0;margin:0;& ~ `,`::before{position:absolute;`,`:0;transition:border-color .25s ease-in-out,box-shadow .1s ease-in-out,background-color .25s ease-in-out,color .25s ease-in-out;border-radius:50%;background-repeat:no-repeat;background-position:center;content:'';}& ~ `,` > svg{position:absolute;}`,`;&:focus ~ `,`::before{outline:none;}& ~ `,`:active::before{transition:border-color 0.1s ease-in-out,background-color 0.1s ease-in-out,color 0.1s ease-in-out;}`,`;&:disabled ~ `,`{cursor:default;}`,`;`],Q,e=>e.theme.rtl?`right`:`left`,Q,({theme:e,$isCompact:t})=>{let n=`${e.space.base*5}px`,r=`${e.space.base*4}px`,i=l(`(${n} - ${r}) / 2`),a=e.iconSizes.sm,o=l(`(${r} - ${a}) / 2`),s=l(`${o} + ${i}`),c=`${e.space.base*(t?1:2)}px`;return u([`top:`,`;width:`,`;height:`,`;& ~ `,`::before{top:`,`;border:`,`;background-size:`,`;width:`,`;height:`,`;box-sizing:border-box;}& ~ `,` > svg{top:`,`;`,`:`,`;width:`,`;height:`,`;}&& ~ `,` ~ `,`{margin-top:`,`;}`],i,r,r,Q,i,e.borders.sm,e.iconSizes.sm,r,r,Q,s,e.rtl?`right`:`left`,o,a,a,Q,X,c)},Q,Q,({theme:e})=>{let t=d({theme:e,variable:`border.emphasis`}),n=d({theme:e,variable:`background.default`}),r=d({theme:e,variable:`foreground.onEmphasis`}),i={theme:e,variable:`background.primaryEmphasis`},a={theme:e,variable:`border.primaryEmphasis`},o=d({...i,transparency:e.opacity[100]}),s=d(a),c=s,l=d({...i,transparency:e.opacity[200]}),f=c,p=d(i),m=c,h={dark:{offset:-100},light:{offset:100}},g={dark:{offset:-200},light:{offset:200}},_=d({...i,...h}),v=d({...a,...h}),y=d({...i,...g}),b=d({...a,...g}),x=d({theme:e,variable:`background.disabled`,transparency:e.opacity[300]});return u([`& ~ `,`::before{border-color:`,`;background-color:`,`;}& ~ `,` > svg{color:`,`;}& ~ `,`:hover::before{border-color:`,`;background-color:`,`;}`,` & ~ `,`:active::before{border-color:`,`;background-color:`,`;}&:checked ~ `,`::before{border-color:`,`;background-color:`,`;}&:enabled:checked ~ `,`:hover::before{border-color:`,`;background-color:`,`;}&:enabled:checked ~ `,`:active::before{border-color:`,`;background-color:`,`;}&:disabled ~ `,`::before{border-color:transparent;background-color:`,`;}`],Q,t,n,Q,r,Q,s,o,P({theme:e,styles:{borderColor:c},selector:`&:focus-visible ~ ${Q}::before`}),Q,f,l,Q,m,p,Q,v,_,Q,b,y,Q,x)},Q,T),Fr=e(Pr).attrs({"data-garden-id":`forms.checkbox`,"data-garden-version":`9.12.5`,type:`checkbox`}).withConfig({displayName:`StyledCheckInput`,componentId:`sc-176jxxe-0`})([`& ~ `,`::before{border-radius:`,`;}`,`;`,`;`],$,e=>e.theme.borderRadii.md,({theme:e})=>{let t={theme:e,variable:`background.primaryEmphasis`},n={theme:e,variable:`border.primaryEmphasis`},r=d(t),i=d(n),a={dark:{offset:-100},light:{offset:100}},o={dark:{offset:-200},light:{offset:200}},s=d({...t,...a}),c=d({...n,...a}),l=d({...t,...o});return u([`&:indeterminate ~ `,`::before{border-color:`,`;background-color:`,`;}&:enabled:indeterminate ~ `,`:hover::before{border-color:`,`;background-color:`,`;}&:enabled:indeterminate ~ `,`:active::before{border-color:`,`;background-color:`,`;}&:disabled:indeterminate ~ `,`::before{border-color:transparent;background-color:`,`;}`],$,i,r,$,c,s,$,d({...n,...o}),l,$,d({theme:e,variable:`background.disabled`,transparency:e.opacity[300]}))},T),Ir=e(X).attrs({"data-garden-id":`forms.radio_message`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledRadioMessage`,componentId:`sc-1pmi0q8-0`})([`padding-`,`:`,`;`,`;`],e=>e.theme.rtl?`right`:`left`,e=>l(`${e.theme.space.base} * 6px`),T),Lr=e(Ir).attrs({"data-garden-id":`forms.checkbox_message`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledCheckMessage`,componentId:`sc-s4p6kd-0`})([``,`;`],T),Rr;function zr(){return zr=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},zr.apply(null,arguments)}var Br=e(function(e){return M.createElement(`svg`,zr({xmlns:`http://www.w3.org/2000/svg`,width:12,height:12,focusable:`false`,viewBox:`0 0 12 12`,"aria-hidden":`true`},e),Rr||=M.createElement(`path`,{fill:`none`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:2,d:`M3 6l2 2 4-4`}))}).attrs({"data-garden-id":`forms.check_svg`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledCheckSvg`,componentId:`sc-fvxetk-0`})([`transition:opacity 0.25s ease-in-out;opacity:0;pointer-events:none;`,`:checked ~ `,` > &{opacity:1;}`,`:indeterminate ~ `,` > &{opacity:0;}`,`;`],Fr,$,Fr,$,T),Vr;function Hr(){return Hr=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},Hr.apply(null,arguments)}var Ur=e(function(e){return M.createElement(`svg`,Hr({xmlns:`http://www.w3.org/2000/svg`,width:12,height:12,focusable:`false`,viewBox:`0 0 12 12`,"aria-hidden":`true`},e),Vr||=M.createElement(`path`,{stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:2,d:`M3 6h6`}))}).attrs({"data-garden-id":`forms.dash_svg`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledDashSvg`,componentId:`sc-z3vq71-0`})([`transition:opacity 0.25s ease-in-out;opacity:0;pointer-events:none;`,`:indeterminate ~ `,` > &{opacity:1;}`,`;`],Fr,$,T),Wr;function Gr(){return Gr=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},Gr.apply(null,arguments)}var Kr=e(function(e){return M.createElement(`svg`,Gr({xmlns:`http://www.w3.org/2000/svg`,width:12,height:12,focusable:`false`,viewBox:`0 0 12 12`,"aria-hidden":`true`},e),Wr||=M.createElement(`circle`,{cx:6,cy:6,r:2,fill:`currentColor`}))}).attrs({"data-garden-id":`forms.radio_svg`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledRadioSvg`,componentId:`sc-1r1qtr1-0`})([`transition:opacity 0.25s ease-in-out;opacity:0;`,`:checked ~ `,` > &{opacity:1;}`,`;`],Pr,Q,T),qr=`forms.toggle_label`,Jr=e=>{let t=e.theme.space.base*10,n=t+e.theme.space.base*2;return u([`padding-`,`:`,`px;&[hidden]{padding-`,`:`,`px;}`],e.theme.rtl?`right`:`left`,n,e.theme.rtl?`right`:`left`,t)},Yr=e($).attrs({"data-garden-id":qr,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledToggleLabel`,componentId:`sc-e0asdk-0`})([``,`;`,`;`],e=>Jr(e),T),Xr=e(Sr).attrs({"data-garden-id":`forms.toggle_hint`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledToggleHint`,componentId:`sc-nziggu-0`})([`padding-`,`:`,`;`,`;`],e=>e.theme.rtl?`right`:`left`,e=>l(`${e.theme.space.base} * 12px`),T),Zr=e(X).attrs({"data-garden-id":`forms.toggle_message`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledToggleMessage`,componentId:`sc-13vuvl1-0`})([`padding-`,`:`,`;& `,`{`,`:`,`;}`,`;`],e=>e.theme.rtl?`right`:`left`,e=>l(`${e.theme.space.base} * 12px`),Cr,e=>e.theme.rtl?`right`:`left`,e=>l(`${e.theme.space.base} * 10px - ${e.theme.iconSizes.md}`),T),Qr;function $r(){return $r=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},$r.apply(null,arguments)}var ei=e(function(e){return M.createElement(`svg`,$r({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),Qr||=M.createElement(`circle`,{cx:8,cy:8,r:6,fill:`currentColor`}))}).attrs({"data-garden-id":`forms.toggle_svg`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledToggleSvg`,componentId:`sc-162xbyx-0`})([`transition:all 0.15s ease-in-out;`,`;`],T),ti=e(Dr).attrs({"data-garden-id":`forms.select`,"data-garden-version":`9.12.5`,as:`select`}).withConfig({displayName:`StyledSelect`,componentId:`sc-8xdxpt-0`})([`opacity:1;cursor:pointer;text-overflow:ellipsis;`,`;`,`;&::-ms-expand{display:none;}&::-ms-value{background-color:transparent;color:inherit;}&:-moz-focusring{transition:none;text-shadow:0 0 0 `,`;color:transparent;}& + `,`{position:absolute;pointer-events:none;}`],({theme:e,$isBare:t,$isCompact:n})=>{let r=t?void 0:l(`${e.iconSizes.md} + ${e.space.base*5}`),i=`${e.space.base*(n?1.5:2.5)+1}px`,a=`${e.space.base*3}px`;return u([`padding-`,`:`,`;& + `,`{top:`,`;`,`:`,`;}`],e.rtl?`left`:`right`,r,Z,i,e.rtl?`left`:`right`,a)},({theme:e})=>u([`&:hover + `,`,&:focus + `,`,&:focus-visible + `,`{color:`,`;}&:disabled + `,`{color:`,`;}`],Z,Z,Z,d({theme:e,variable:`foreground.subtle`,dark:{offset:-100},light:{offset:100}}),Z,d({theme:e,variable:`foreground.disabled`})),e=>d({theme:e.theme,variable:`foreground.default`}),Z),ni=e(kr).attrs({"data-garden-id":`forms.select_wrapper`,"data-garden-version":`9.12.5`}).withConfig({displayName:`StyledSelectWrapper`,componentId:`sc-i7b6hw-0`})([`position:relative;padding:0;overflow:visible;`,`;& > `,`{border-color:transparent;background-color:transparent;`,`{box-shadow:unset;}}`],({theme:e,$isCompact:t})=>u([`max-height:`,`;`],`${e.space.base*(t?8:10)}px`),ti,N),ri=(0,M.createContext)(void 0),ii=()=>(0,M.useContext)(ri),ai=M.forwardRef((e,t)=>{let{hasHint:n,setHasHint:r,getHintProps:i}=_r()||{},a=ii();(0,M.useEffect)(()=>(!n&&r&&r(!0),()=>{n&&r&&r(!1)}),[n,r]);let o;o=a===`checkbox`?Nr:a===`radio`?Mr:a===`toggle`?Xr:Sr;let s=e;return i&&(s=i(s)),M.createElement(o,Object.assign({ref:t},s))});ai.displayName=`Field.Hint`;var oi=[`success`,`warning`,`error`],si,ci;function li(){return li=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},li.apply(null,arguments)}var ui=function(e){return M.createElement(`svg`,li({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),si||=M.createElement(`g`,{fill:`none`,stroke:`currentColor`},M.createElement(`circle`,{cx:7.5,cy:8.5,r:7}),M.createElement(`path`,{strokeLinecap:`round`,d:`M7.5 4.5V9`})),ci||=M.createElement(`circle`,{cx:7.5,cy:12,r:1,fill:`currentColor`}))},di,fi;function pi(){return pi=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},pi.apply(null,arguments)}var mi=function(e){return M.createElement(`svg`,pi({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),di||=M.createElement(`path`,{fill:`none`,stroke:`currentColor`,strokeLinecap:`round`,d:`M.88 13.77L7.06 1.86c.19-.36.7-.36.89 0l6.18 11.91c.17.33-.07.73-.44.73H1.32c-.37 0-.61-.4-.44-.73zM7.5 6v3.5`}),fi||=M.createElement(`circle`,{cx:7.5,cy:12,r:1,fill:`currentColor`}))},hi;function gi(){return gi=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},gi.apply(null,arguments)}var _i=function(e){return M.createElement(`svg`,gi({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),hi||=M.createElement(`g`,{fill:`none`,stroke:`currentColor`},M.createElement(`path`,{strokeLinecap:`round`,strokeLinejoin:`round`,d:`M4 9l2.5 2.5 5-5`}),M.createElement(`circle`,{cx:7.5,cy:8.5,r:7})))},vi=({validation:e,children:t,...n})=>M.createElement(Cr,Object.assign({"aria-hidden":!1,role:`img`},n),e?{error:M.createElement(ui,null),success:M.createElement(_i,null),warning:M.createElement(mi,null)}[e]:t);vi.displayName=`Field.MessageIcon`,vi.propTypes={validation:F.default.oneOf(oi)};var yi=M.forwardRef(({validation:e,validationLabel:t,children:n,...r},i)=>{let{hasMessage:a,setHasMessage:o,getMessageProps:s}=_r()||{},c=ii();(0,M.useEffect)(()=>(!a&&o&&o(!0),()=>{a&&o&&o(!1)}),[a,o]);let l;l=c===`checkbox`?Lr:c===`radio`?Ir:c===`toggle`?Zr:X;let u={$validation:e,$validationLabel:t,...r};s&&(u=s(u));let d=re(yi,u,`$validationLabel`,e,e!==void 0);return M.createElement(l,Object.assign({ref:i},u),!!e&&M.createElement(vi,{validation:e,"aria-label":d}),n)});yi.displayName=`Field.Message`,yi.propTypes={validation:F.default.oneOf(oi),validationLabel:F.default.string};var bi=(0,M.createContext)(void 0),xi=()=>(0,M.useContext)(bi),Si=M.forwardRef(({children:e,isRegular:t,...n},r)=>{let i=_r(),a=xi(),o=ii(),s=a&&t===void 0?!0:t,c=n;if(i&&(c=i.getLabelProps(c),o===void 0)){let{setIsLabelActive:e,setIsLabelHovered:t}=i;c.onMouseUp=R(n.onMouseUp,()=>{e(!1)}),c.onMouseDown=R(n.onMouseDown,()=>{e(!0)}),c.onMouseEnter=R(n.onMouseEnter,()=>{t(!0)}),c.onMouseLeave=R(n.onMouseLeave,()=>{t(!1)})}return o===`radio`?M.createElement(Q,Object.assign({ref:r},c,{$isRegular:s}),M.createElement(Kr,null),e):o===`checkbox`?(c.onClick=R(c.onClick,e=>{let t=navigator?.userAgent.toLowerCase().indexOf(`firefox`)>-1;if(i&&t&&e.target instanceof Element){let t=e.target.getAttribute(`for`);if(!t)return;let n=document.getElementById(t);n&&n.type===`checkbox`&&(e.shiftKey&&(n.click(),n.checked=!0),n.focus())}}),M.createElement($,Object.assign({ref:r},c,{$isRegular:s}),M.createElement(Br,null),M.createElement(Ur,null),e)):o===`toggle`?M.createElement(Yr,Object.assign({ref:r},c,{$isRegular:s}),M.createElement(ei,null),e):M.createElement(br,Object.assign({ref:r},c,{$isRegular:s}),e)});Si.displayName=`Field.Label`,Si.propTypes={isRegular:F.default.bool};var Ci=M.forwardRef((e,t)=>{let[n,r]=(0,M.useState)(!1),[i,a]=(0,M.useState)(!1),[o,s]=(0,M.useState)(!1),[c,l]=(0,M.useState)(!1),{getInputProps:u,getMessageProps:d,...f}=mr({idPrefix:e.id,hasHint:n,hasMessage:i}),p=(0,M.useMemo)(()=>({...f,getInputProps:u,getMessageProps:d,isLabelActive:o,setIsLabelActive:s,isLabelHovered:c,setIsLabelHovered:l,hasHint:n,setHasHint:r,hasMessage:i,setHasMessage:a}),[f,u,d,o,c,n,i]);return M.createElement(gr.Provider,{value:p},M.createElement(vr,Object.assign({},e,{ref:t})))});Ci.displayName=`Field`;var wi=Ci;wi.Hint=ai,wi.Label=Si,wi.Message=yi;var Ti=(0,M.createContext)(void 0),Ei=()=>(0,M.useContext)(Ti),Di=M.forwardRef(({onSelect:e,isBare:t,isCompact:n,focusInset:r,validation:i,...a},o)=>{let s=_r(),c=Ei(),l=a;s&&(l=s.getInputProps(l));let u=a.readOnly?R(e,e=>{e.currentTarget.select()}):e;return M.createElement(Dr,Object.assign({ref:o,onSelect:u},l,{$isBare:t,$isCompact:c?c.isCompact:n,$focusInset:c&&r===void 0?!0:r,$validation:i}))});Di.propTypes={isCompact:F.default.bool,isBare:F.default.bool,focusInset:F.default.bool,validation:F.default.oneOf(oi)},Di.displayName=`Input`;var Oi;function ki(){return ki=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},ki.apply(null,arguments)}var Ai=function(e){return M.createElement(`svg`,ki({xmlns:`http://www.w3.org/2000/svg`,width:16,height:16,focusable:`false`,viewBox:`0 0 16 16`,"aria-hidden":`true`},e),Oi||=M.createElement(`path`,{fill:`currentColor`,d:`M12.688 5.61a.5.5 0 01.69.718l-.066.062-5 4a.5.5 0 01-.542.054l-.082-.054-5-4a.5.5 0 01.55-.83l.074.05L8 9.359l4.688-3.75z`}))},ji=({isDisabled:e,isFocused:t,isHovered:n,isRotated:r,...i})=>M.createElement(Z,Object.assign({$position:`start`,$isDisabled:e,$isFocused:t,$isHovered:n,$isRotated:r},i));ji.displayName=`FauxInput.StartIcon`;var Mi=ji,Ni=({isDisabled:e,isFocused:t,isHovered:n,isRotated:r,...i})=>M.createElement(Z,Object.assign({$position:`end`,$isDisabled:e,$isFocused:t,$isHovered:n,$isRotated:r},i));Ni.displayName=`FauxInput.EndIcon`;var Pi=Ni,Fi=(0,M.forwardRef)(({disabled:e,focusInset:t,isBare:n,isCompact:r,isFocused:i,isHovered:a,onBlur:o,onFocus:s,readOnly:c,validation:l,mediaLayout:u,...d},f)=>{let[p,m]=(0,M.useState)(!1),h=R(s,()=>{m(!0)}),g=R(o,()=>{m(!1)});return M.createElement(kr,Object.assign({onFocus:h,onBlur:g,$focusInset:t,$isBare:n,$isCompact:r,$isDisabled:e,$isFocused:i===void 0?p:i,$isHovered:a,$isReadOnly:c,$mediaLayout:u,$validation:l,tabIndex:e?void 0:0},d,{ref:f}))});Fi.displayName=`FauxInput`,Fi.propTypes={isCompact:F.default.bool,isBare:F.default.bool,focusInset:F.default.bool,disabled:F.default.bool,readOnly:F.default.bool,validation:F.default.oneOf(oi),isFocused:F.default.bool,isHovered:F.default.bool};var Ii=Fi;Ii.EndIcon=Pi,Ii.StartIcon=Mi;var Li=M.forwardRef(({disabled:e,isCompact:t,validation:n,focusInset:r,isBare:i,...a},o)=>{let s=_r(),c={$focusInset:r,$isBare:i,$isCompact:t,$validation:n,disabled:e,ref:o,...a};return s&&(c=s.getInputProps(c)),M.createElement(ni,{$isCompact:t,$isBare:i,$isDisabled:e,$validation:n,$focusInset:r},M.createElement(ti,c),!i&&M.createElement(Ii.EndIcon,{isDisabled:e},M.createElement(Ai,null)))});Li.propTypes={isCompact:F.default.bool,isBare:F.default.bool,focusInset:F.default.bool,validation:F.default.oneOf(oi)},Li.displayName=`Select`;var Ri=({ticketData:e,onWorkItemLinked:t,caseRecordId:n,linkedWorkItemIds:r=[]})=>{let i=be(),[a,o]=(0,M.useState)(``),[s,c]=(0,M.useState)([]),[l,u]=(0,M.useState)(!1),[d,f]=(0,M.useState)(null),[p,m]=(0,M.useState)(null),[h,g]=(0,M.useState)(``);(0,M.useEffect)(()=>{_()},[]);let _=async()=>{try{f(null);let t=(await V(i)).find(t=>t.external_uid+``==e.brand.id+``);g(t)}catch(e){f(e.message||`Failed to load suggestions`)}},v=async()=>{if(!a.trim()){f(`Enter a search term`);return}try{u(!0),f(null);let t=await ot(i,a,h.workspace_id,e);c(t),t.length===0&&f(`No work items found matching your search`)}catch(e){f(e.message||`Failed to search work items`)}finally{u(!1)}},y=()=>{o(``),c([]),f(null)},b=async a=>{if(!r.some(e=>e+``==a.id+``))try{m(a.id),f(null),await ft(i,e,a.id,n),t(a)}catch(e){f(e.message||`Failed to link work item`)}finally{m(null)}};return(0,L.jsxs)(hn,{children:[(0,L.jsx)(Di,{isCompact:!0,focusInset:!0,value:a,onChange:e=>o(e.target.value),onKeyUp:e=>e.key===`Enter`&&v(),placeholder:`Search title or description`}),(0,L.jsxs)(Tn,{children:[(0,L.jsx)(or,{size:`small`,onClick:v,disabled:l,children:l?`Searching...`:`Search`}),(a||s.length>0)&&(0,L.jsx)(Y,{size:`small`,onClick:y,children:`Clear`})]}),d&&(0,L.jsx)(G,{type:`warning`,style:{marginTop:`2px`,clear:`both`},children:d}),l&&(0,L.jsx)(mn,{children:(0,L.jsx)(I,{})}),!l&&s.length>0&&(0,L.jsxs)(`div`,{style:{marginTop:`0px`},children:[(0,L.jsx)(jn,{children:`Search results`}),s.map(e=>{let t=r.some(t=>t+``==e.id+``),n=ht(e);return(0,L.jsxs)(dn,{children:[(0,L.jsx)(fn,{children:e.title}),(0,L.jsxs)(En,{children:[(0,L.jsxs)(pn,{children:[(0,L.jsx)(wn,{status:n,children:n}),(0,L.jsx)(Y,{size:`small`,onClick:()=>fr(i,e),children:`View Details`})]}),(0,L.jsx)(or,{size:`small`,onClick:()=>b(e),disabled:p===e.id||t,children:t?`Linked`:p===e.id?`Linking...`:`Link`})]})]},e.id)})]})]})},zi=`data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='16'%20height='16'%20focusable='false'%20viewBox='0%200%2016%2016'%3e%3cg%20fill='none'%20stroke='currentColor'%3e%3ccircle%20cx='8'%20cy='8'%20r='7.5'/%3e%3ccircle%20cx='8'%20cy='5.5'%20r='2'/%3e%3cpath%20stroke-linecap='round'%20d='M11.5%2012c-.6-1.5-1.8-2.5-3.5-2.5s-2.9%201-3.5%202.5'/%3e%3c/g%3e%3c/svg%3e`,Bi=new Set([`bug`]),Vi=new Set([`feature`]),Hi=new Set([`tech-debt`,`task`]),Ui=e=>e?.api_name||null,Wi=(e,t)=>{let n=Ui(e.work_type);return n?t===`due_by`?Bi.has(n):t===`planned_on`?Vi.has(n):!Hi.has(n)||t!==`due_by`&&t!==`planned_on`:t!==`planned_on`},Gi=e.div`
  display: flex;
  flex-direction: column;
  min-height: calc(100vh - 16px);
  height: calc(100vh - 16px);
  padding: 8px 10px 12px;
  box-sizing: border-box;

  [role="tablist"] {
    display: flex;
    gap: 24px;
    margin-bottom: 0;
    border-bottom: 0;
  }

  [role="tab"] {
    min-height: 25px;
    padding: 2px 0;
    font-size: 13px;
    font-weight: 500;
  }

  [role="tabpanel"] {
    padding-top: 3px;
  }
`;e.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
`;var Ki=e.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 8px;
`,qi=e.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid ${e=>d({theme:e.theme,variable:`border.default`})};
`,Ji=e.div`
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 6px;
  border-bottom: 1px solid ${e=>d({theme:e.theme,variable:`border.default`})};
`,Yi=e.div`
  flex: 1 1 auto;
  margin-bottom: 12px;
`,Xi=e.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  margin-bottom: auto;
  padding: 0;
  border: 0;
  background: transparent;
  color: #1f73b7;
  cursor: pointer;

  &:hover:not(:disabled) {
    color: #165e96;
  }

  &:disabled {
    opacity: 0.45;
    cursor: default;
  }

  img,
  svg {
    width: 16px;
    height: 16px;
    flex: 0 0 auto;
  }
`;e(Xi)`
  width: 22px;
  height: 22px;
  margin-bottom: 2px;
  flex: 0 0 auto;
`;var Zi=e.div`
  margin-top: 16px;
`,Qi=e.button`
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0;
  border: 0;
  background: transparent;
  color: #1f73b7;
  cursor: pointer;
  font-size: 12px;
  font-weight: 400;
  line-height: 1.2;

  &:hover:not(:disabled) {
    color: #165e96;
    text-decoration: underline;
  }

  &:disabled {
    opacity: 0.45;
    cursor: default;
  }

  img,
  svg {
    width: 14px;
    height: 14px;
    flex: 0 0 auto;
  }
`,$i=`Your ticket has been forwarded to the team.`,ea=5e3,ta=({workItem:e,type:t,caseRecordId:n,onUnlink:r,ticketData:i,showForwardedMessage:a=!1,onForwardedMessageHidden:o,isAdmin:s,onConfigureClick:c,showSeparator:l=!1})=>{let u=be(),[d,f]=(0,M.useState)(!1),[p,m]=(0,M.useState)(null),[h,g]=(0,M.useState)(!1),[_,v]=(0,M.useState)(!1),[y,b]=(0,M.useState)(a);(0,M.useEffect)(()=>{x()},[]),(0,M.useEffect)(()=>{if(!a)return;b(!0);let e=window.setTimeout(()=>{b(!1),o?.()},ea);return()=>window.clearTimeout(e)},[a,o]);let x=async()=>{try{m(null),v(!1),(await V(u)).find(e=>e.external_uid+``==i.brand.id+``)?.workspace_id||v(!0)}catch(e){m(e.message||`Failed to load workspace`)}},S=()=>{g(!0)},C=async()=>{try{f(!0),m(null),g(!1),await pt(u,i,e.id,n),r()}catch(e){m(e.message||`Failed to unlink work item`),f(!1)}},w=()=>{g(!1)},T=()=>{if(!e?.view_url){m(`View URL is not available for this work item.`);return}window.open(e.view_url,`_blank`,`noopener,noreferrer`)},E=e=>{if(!e)return`Not set`;let t=new Date(e);return Number.isNaN(t.getTime())?`Not set`:`${String(t.getDate()).padStart(2,`0`)}/${t.toLocaleString(`en-GB`,{month:`short`})}/${String(t.getFullYear()).slice(-2)}`},D=e=>e?.name||`Not assigned`,ee=e.title||`Untitled`,O=ht(e),k=D(e.owner),te=k.length>18?`${k.slice(0,18)}...`:k,A=e.planned_on?E(e.planned_on):``,ne=!!e.planned_on&&Wi(e,`planned_on`);return(0,L.jsxs)(`div`,{children:[p&&(0,L.jsx)(G,{type:`error`,style:{marginBottom:`12px`},children:p}),_&&(0,L.jsxs)(G,{type:`warning`,style:{marginBottom:`12px`},children:[`This Zendesk brand is not mapped to a workspace yet.`,s?(0,L.jsxs)(L.Fragment,{children:[` `,(0,L.jsx)(Qi,{type:`button`,onClick:c,title:`Reconfigure`,"aria-label":`Reconfigure`,children:`Reconfigure`})]}):` Please contact your admin to configure the mapping.`]}),h&&(0,L.jsxs)(G,{type:`warning`,style:{marginBottom:`12px`},children:[(0,L.jsx)(`div`,{style:{marginBottom:`8px`},children:`Are you sure you want to unlink this work item?`}),(0,L.jsxs)(`div`,{style:{display:`flex`,gap:`8px`},children:[(0,L.jsx)(sr,{size:`small`,onClick:C,disabled:d,children:d?`Unlinking...`:`Unlink`}),(0,L.jsx)(or,{size:`small`,onClick:w,disabled:d,children:`Cancel`})]})]}),t===`case-records`?(0,L.jsxs)(gn,{$showSeparator:l,style:{paddingTop:`12px`,paddingBottom:`12px`},children:[y&&(0,L.jsx)(G,{type:`success`,style:{marginBottom:`12px`},children:$i}),(0,L.jsxs)(Cn,{style:{marginBottom:`6px`},children:[(0,L.jsxs)(_n,{children:[`Reported on: `,e.created_at?E(e.created_at):`Not set`]}),(0,L.jsx)(wn,{status:O,children:O})]}),(0,L.jsxs)(Cn,{children:[(0,L.jsxs)(_n,{style:{display:`inline-flex`,alignItems:`center`,gap:`4px`},children:[`Assigned to: `,D(e.owner)]}),(0,L.jsx)(Y,{size:`small`,onClick:T,disabled:!e?.view_url,children:`View in Prodbench`})]})]}):(0,L.jsxs)(gn,{$showSeparator:l,children:[(0,L.jsx)(fn,{children:ee}),(0,L.jsxs)(Dn,{style:{marginTop:`6px`},children:[(0,L.jsx)(On,{children:(0,L.jsx)(wn,{status:O,children:O})}),(0,L.jsx)(kn,{children:(0,L.jsxs)(An,{children:[ne&&(0,L.jsxs)(bn,{$muted:!e.planned_on,children:[A,(0,L.jsx)(xn,{children:`ETA`})]}),(0,L.jsx)(`img`,{src:zi,alt:`owner`,"aria-hidden":`true`,width:`16`,height:`16`}),(0,L.jsx)(Sn,{title:k,children:te})]})})]}),(0,L.jsxs)(vn,{children:[(0,L.jsx)(Y,{size:`small`,onClick:S,disabled:d||h,children:`Unlink`}),(0,L.jsx)(Y,{size:`small`,onClick:T,disabled:!e?.view_url,children:`View in Prodbench`})]})]})]})},na=async(e,t)=>{try{let{baseUrl:n}=await H(e),r=`${n}/integrations/zendesk/tickets/${t.id}/case-records.json`;return await e.request(ia(r))}catch{return null}},ra=async e=>{let t=await e.get([`ticket.id`,`ticket.subject`,`ticket.description`,`ticket.comments`,`ticket.type`,`ticket.createdAt`,`ticket.priority`,`ticket.dueBy`,`ticket.requester.id`,`ticket.requester.name`,`ticket.requester.email`,`ticket.assignee`,`ticket.assignee.user.id`,`ticket.assignee.user.name`,`ticket.assignee.user.email`,`ticket.brand.id`,`ticket.brand.name`]);return{id:t[`ticket.id`],subject:t[`ticket.subject`],description:t[`ticket.description`],type:t[`ticket.type`],comments:t[`ticket.comments`],priority:t[`ticket.priority`],created_at:t[`ticket.createdAt`],due_by:t[`ticket.dueBy`]||null,requester:{id:t[`ticket.requester.id`],name:t[`ticket.requester.name`],email:t[`ticket.requester.email`]||null},brand:{id:t[`ticket.brand.id`],name:t[`ticket.requester.name`]},assignee:t[`ticket.assignee`]?{id:t[`ticket.assignee.user.id`],name:t[`ticket.assignee.user.name`]||null,email:t[`ticket.assignee.user.email`]||null}:null}},ia=(e,t=`GET`)=>{try{return{url:e,type:t,contentType:`application/json`,headers:{"ngrok-skip-browser-warning":!0,Authorization:`{{setting.apiToken}}`,"X-Zendesk-UA-Override":`none`,"X-Requested-With":``},accepts:`application/json`,secure:!0}}catch(e){console.log(`options error:`,e)}},aa=({isAdmin:e,onConfigureClick:t})=>{let n=be(),[r,i]=(0,M.useState)(!0),[a,o]=(0,M.useState)(null),[s,c]=(0,M.useState)(null),[l,u]=(0,M.useState)(null),[d,f]=(0,M.useState)(`suggestions`),[p,m]=(0,M.useState)(!0),[h,g]=(0,M.useState)([]),[_,v]=(0,M.useState)(!1),[y,b]=(0,M.useState)(!1),[x,S]=(0,M.useState)(!1),C=()=>e?(0,L.jsx)(Xi,{type:`button`,onClick:t,title:`Reconfigure App`,"aria-label":`Reconfigure App`,children:(0,L.jsx)(`img`,{src:Je,alt:``,"aria-hidden":`true`})}):null;(0,M.useEffect)(()=>{w()},[]),(0,M.useEffect)(()=>{T()},[]);let w=async()=>{try{i(!0),o(null);let e=await ra(n),[t,r]=await Promise.all([V(n,!0),na(n,e)]),a=t.find(t=>t.external_uid+``==e.brand.id+``);c(e),v(!a),E(r)}catch(e){o(e.message||`Failed to load ticket data`)}finally{i(!1)}},T=async()=>{try{let e=(await n.get(`ticket.comments`))[`ticket.comments`]||[],t=e[e.length-1];if(!t){g([]);return}let r=[];t.imageAttachments&&t.imageAttachments.length>0&&t.imageAttachments.forEach(function(e){r.push({filename:e.filename,content_type:e.contentType,content_url:e.contentUrl,inline:!1})}),t.nonImageAttachments&&t.nonImageAttachments.length>0&&t.nonImageAttachments.forEach(function(e){r.push({filename:e.filename,content_type:e.contentType,content_url:e.contentUrl,inline:!1})}),g(r)}catch(e){console.error(`Failed to fetch attachments:`,e)}},E=e=>{if(!Array.isArray(e)||e.length===0){u(null),m(!0);return}let t=e.find(e=>Array.isArray(e.work_items)&&e.work_items.length>0);u(t?{workItems:t.work_items,caseRecordId:t.id,type:`work-items`}:{workItems:e,caseRecordId:e[0].id,type:`case-records`}),m(!1)},D=async e=>{try{i(!0),o(null);let e=await na(n,s);E(e),S(!1)}catch(e){o(e.message||`Failed to load linked data.`)}finally{i(!1)}},ee=async e=>{try{i(!0),o(null);let e=await na(n,s);E(e),S(!1)}catch(e){o(e.message||`Failed to load linked data.`)}finally{i(!1)}},O=async()=>{try{i(!0),o(null);let e=await na(n,s);E(e),(!Array.isArray(e)||e.length===0)&&S(!1)}catch(e){o(e.message||`Failed to load linked data.`)}finally{i(!1)}},k=async()=>{try{i(!0),o(null),await ut(n,s,h);let e=await na(n,s);E(e),b(!0),S(!1)}catch(e){o(e.message||`Failed to forward ticket data to prodbench.`)}finally{i(!1)}},te=(0,M.useCallback)(()=>{b(!1)},[]);return r?(0,L.jsx)(Gi,{children:(0,L.jsx)(`div`,{style:{display:`flex`,justifyContent:`center`,padding:`40px`},children:(0,L.jsx)(I,{})})}):a?(0,L.jsx)(Gi,{children:(0,L.jsxs)(G,{type:`error`,children:[(0,L.jsx)(K,{children:`Error`}),a]})}):_?(0,L.jsx)(Gi,{children:(0,L.jsx)(Yi,{children:(0,L.jsxs)(G,{type:`warning`,children:[(0,L.jsx)(K,{children:`Configuration Required`}),`This Zendesk brand is not mapped to a workspace yet.`,e?(0,L.jsxs)(L.Fragment,{children:[` `,(0,L.jsx)(Qi,{type:`button`,onClick:()=>t({startEditing:!0}),title:`Reconfigure`,"aria-label":`Reconfigure`,children:`Reconfigure`})]}):` Please contact your admin to configure the mapping.`]})})}):(0,L.jsx)(Gi,{children:l?(0,L.jsx)(Yi,{children:x?(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(Ki,{children:[(0,L.jsx)(jn,{style:{margin:0},children:`Search work items`}),(0,L.jsx)(Xi,{type:`button`,"aria-label":`Close search panel`,title:`Close search panel`,onClick:()=>S(!1),children:`×`})]}),(0,L.jsx)(Ri,{ticketData:s,onWorkItemLinked:ee,caseRecordId:l.caseRecordId,linkedWorkItemIds:l.type===`work-items`?l.workItems.map(e=>e.id):[]})]}):(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(Ki,{children:[(0,L.jsx)(jn,{style:{margin:0},children:l.type===`case-records`?`Forwarded to Prodbench`:`Linked Work`}),C()]}),l.workItems.map((n,r)=>(0,L.jsx)(ta,{workItem:n,type:l.type||`work-items`,caseRecordId:l.caseRecordId,onUnlink:O,ticketData:s,showForwardedMessage:l.type===`case-records`&&r===0&&y,onForwardedMessageHidden:te,isAdmin:e,onConfigureClick:t,showSeparator:l.type===`work-items`&&r<l.workItems.length-1},n.id)),(0,L.jsx)(qi,{children:(0,L.jsx)(or,{size:`small`,onClick:()=>S(!0),children:`Link More`})})]})}):(0,L.jsx)(Yi,{children:(0,L.jsxs)(B,{selectedItem:d,onChange:f,children:[(0,L.jsxs)(Ji,{children:[(0,L.jsxs)(B.TabList,{"aria-label":`Work item options`,children:[(0,L.jsx)(B.Tab,{item:`suggestions`,children:`Suggestions`}),(0,L.jsx)(B.Tab,{item:`search`,children:`Search`})]}),C()]}),(0,L.jsxs)(B.TabPanel,{item:`suggestions`,children:[(0,L.jsx)(pr,{ticketData:s,onWorkItemLinked:D}),p&&(0,L.jsx)(Zi,{children:(0,L.jsx)(rr,{size:`small`,onClick:()=>k(),style:{width:`100%`},children:`Forward to Prodbench`})})]}),(0,L.jsx)(B.TabPanel,{item:`search`,children:(0,L.jsx)(Ri,{ticketData:s,onWorkItemLinked:D})})]})})})},oa=e.div`
  padding: 4px 8px 8px;
  
  h3 {
    margin-bottom: 12px;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
  
  p {
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
    line-height: 1.45;
    font-size: 12px;
  }
`,sa=e.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  
  h3 {
    margin: 0;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`,ca=e.div`
  margin-bottom: 16px;
  
  h4 {
    margin-bottom: 10px;
    font-size: 12px;
    font-weight: 500;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
`,la=e.div`
  padding: 10px 12px;
  border: 1px solid ${e=>d({theme:e.theme,variable:`border.default`})};
  border-radius: 8px;
  background: ${e=>d({theme:e.theme,variable:`background.default`})};
  
  &:last-child {
    margin-bottom: 0;
  }

  label {
    font-size: 10px;
    font-weight: 500;
    margin-bottom: 3px;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }
  
  select {
    width: 100%;
  }
    
`,ua=e.div`
  padding: 10px 12px;
  border: 1px solid ${e=>d({theme:e.theme,variable:`border.default`})};
  border-radius: 8px;
  background: ${e=>d({theme:e.theme,variable:`background.default`})};
  
  strong {
    color: ${e=>d({theme:e.theme,variable:`foreground.default`})};
  }

  div:first-child {
    font-size: 13px;
    font-weight: 500;
  }
`,da=e.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 400px;
  overflow-y: auto;
`,fa=({onSave:e,onBack:t,startEditing:n=!1,initialAlert:r=null})=>{let i=be(),[a,o]=(0,M.useState)(!0),[s,c]=(0,M.useState)(!1),[l,u]=(0,M.useState)(null),[d,f]=(0,M.useState)([]),[p,m]=(0,M.useState)([]),[h,g]=(0,M.useState)([]),[_,v]=(0,M.useState)(!1),[y,b]=(0,M.useState)([]),x=(0,M.useRef)(null),S=(0,M.useCallback)(async()=>{try{if(o(!0),u(null),!await Ye(i)){u({type:`error`,message:`Only administrators can access brand mapping configuration.`}),o(!1);return}let[e,t,a]=await Promise.all([i.request(`/api/v2/brands.json`),$e(i,!0),V(i,!0)]);f(e.brands||[]),et(`workspaces`,t),m(t||[]);let s=a||[];g(s),b(s),(n||s.length===0)&&v(!0),r&&(u(r),x.current=setTimeout(()=>u(null),3e3))}catch(e){u({type:`error`,message:e.message||`Failed to load configuration data`})}finally{o(!1)}},[i,r,n]);(0,M.useEffect)(()=>(S(),()=>{x.current&&clearTimeout(x.current)}),[S]);let C=(e,t)=>{if(!t){g(t=>t.filter(t=>t.external_uid+``!=e+``));return}let n=p.find(e=>e.id+``==t+``);n&&g(r=>r.find(t=>t.external_uid+``==e+``)?r.map(r=>r.external_uid+``==e+``?{...r,workspace_id:t,name:n.name}:r):[...r,{external_uid:e,workspace_id:t,name:n.name}])},w=()=>{v(!0)},T=()=>{g(y),v(!1),u(null)},E=async()=>{try{c(!0),u(null);let t=y.filter(e=>e.id&&!h.some(t=>t.id===e.id));await Promise.all([Xe(i,h),...t.map(e=>Ze(i,e.id))]);let n=await V(i,!0);g(n),b(n),et(`brandMappings`,n),v(!1),u({type:`success`,message:`Saved brand mappings successfully.`}),setTimeout(()=>u(null),3e3),e()}catch(e){u({type:`error`,message:e.message||`Failed to save brand mappings`})}finally{c(!1)}},D=e=>{let t=h.find(t=>t.external_uid+``==e+``);if(!t)return`Not mapped`;let n=p.find(e=>e.id+``==t.workspace_id+``);return n?n.name:`Not mapped`};return a?(0,L.jsx)(oa,{children:(0,L.jsx)(`div`,{style:{display:`flex`,justifyContent:`center`,padding:`24px`},children:(0,L.jsx)(I,{})})}):(0,L.jsxs)(oa,{children:[(0,L.jsx)(sa,{children:(0,L.jsx)(`div`,{style:{display:`flex`,gap:`8px`},children:!_&&(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(ir,{size:`small`,onClick:w,children:`Edit Mappings`}),(0,L.jsx)(ir,{size:`small`,onClick:t,children:`Back`})]})})}),l&&(0,L.jsx)(G,{type:l.type,children:l.message}),_?(0,L.jsxs)(L.Fragment,{children:[(0,L.jsxs)(ca,{children:[(0,L.jsx)(`p`,{style:{fontSize:`13px`,marginBottom:`12px`},children:`Map each Zendesk brand to a product in your product management tool.`}),(0,L.jsx)(da,{children:d.map(e=>(0,L.jsx)(la,{children:(0,L.jsxs)(wi,{children:[(0,L.jsx)(wi.Label,{children:e.name}),(0,L.jsxs)(Li,{isCompact:!0,value:h.find(t=>t.external_uid+``==e.id+``)?.workspace_id??``,onChange:t=>C(e.id,t.target.value),children:[(0,L.jsx)(`option`,{value:``,children:`Select a product`}),p.map(e=>(0,L.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]})},e.id))})]}),(0,L.jsxs)(`div`,{style:{display:`flex`,gap:`8px`},children:[(0,L.jsx)(rr,{size:`small`,onClick:E,disabled:s,children:s?`Saving...`:`Save Mappings`}),(0,L.jsx)(ir,{size:`small`,onClick:T,disabled:s,children:`Cancel`})]})]}):(0,L.jsxs)(ca,{children:[(0,L.jsx)(`p`,{style:{fontSize:`13px`,marginBottom:`12px`},children:`Current brand to product mappings:`}),(0,L.jsx)(da,{children:d.map(e=>(0,L.jsxs)(ua,{children:[(0,L.jsx)(`div`,{style:{fontWeight:600,fontSize:`13px`,marginBottom:`4px`},children:e.name}),(0,L.jsx)(`div`,{style:{fontSize:`12px`,color:D(e.id)===`Not mapped`?`#999`:`inherit`},children:D(e.id)})]},e.id))})]})]})},pa=()=>{let[e,t]=(0,M.useState)(!0),[n,r]=(0,M.useState)(null),[i,a]=(0,M.useState)(null),[o,s]=(0,M.useState)(!1),[c,l]=(0,M.useState)(!1),[u,d]=(0,M.useState)(!1),[f,p]=(0,M.useState)(!1),[m,h]=(0,M.useState)(null),[g,_]=(0,M.useState)(!1);(0,M.useEffect)(()=>{v()},[]);let v=async()=>{try{if(t(!0),a(null),!window.ZAFClient)throw Error(`Zendesk client not available1`);let e=window.ZAFClient.init();r(e);let[n,i,o,c,u]=await Promise.all([ra(e),e.request(`/api/v2/brands.json`),Ye(e),$e(e),V(e,!0)]);s(o);let f=u.length>0;if(d(f),c&&c.length===1){let t=i.brands||[];if(!f&&t.length===1){let n=c[0];console.info(`save default workspace`),await Xe(e,[{external_uid:(t.find(e=>e.default)||t[0]).id,workspace_id:n.id,name:n.name}]);let r=await V(e,!0);et(`brandMappings`,r),d(r.length>0)}else o&&!f&&t.length>1&&(p(!0),h({type:`warning`,message:`Brand mapping required.`}),l(!0))}else if(o&&!f)console.log(`mappings loaded:`,u),p(!0),h({type:`warning`,message:`Brand mapping required.`}),l(!0);else{let e=n;if(!e.id||e.id===`new`){_(!0),t(!1);return}}try{await e.invoke(`resize`,{width:`100%`,height:`300px`})}catch(e){console.warn(`Failed to resize app:`,e)}}catch(e){a(e.message||`Failed to initialize app`)}finally{t(!1)}};return e?(0,L.jsx)(`div`,{style:{display:`flex`,justifyContent:`center`,alignItems:`center`,padding:`40px`},children:(0,L.jsx)(I,{})}):g?(0,L.jsx)(`div`,{style:{padding:`16px`},children:(0,L.jsx)(G,{type:`info`,children:`This app is only available for existing tickets. Please save the ticket first.`})}):i?(0,L.jsx)(`div`,{style:{padding:`16px`},children:(0,L.jsxs)(G,{type:`error`,children:[(0,L.jsx)(K,{children:`Error`}),i]})}):!o&&!u?(0,L.jsx)(`div`,{style:{padding:`16px`},children:(0,L.jsxs)(G,{type:`warning`,children:[(0,L.jsx)(K,{children:`Configuration Required`}),`Request your Admin to configure this App`]})}):n?(0,L.jsx)(ye,{client:n,children:c?(0,L.jsx)(fa,{onSave:()=>{d(!0)},onBack:()=>{p(!1),h(null),l(!1)},startEditing:f,initialAlert:m}):(0,L.jsx)(aa,{isAdmin:o,onConfigureClick:({startEditing:e=!1}={})=>{p(e),h(null),l(!0)}})}):(0,L.jsx)(`div`,{style:{padding:`16px`},children:(0,L.jsxs)(G,{type:`error`,children:[(0,L.jsx)(K,{children:`Error`}),`Zendesk client not available`]})})},ma=`550px`,ha=`100%`,ga=2e3,_a=new URLSearchParams(location.search).get(`colorScheme`),va=e.div`
  background-color: ${e=>d({theme:e.theme,variable:`background.default`})};
  min-height: 100vh;
  font-family: Lato, "Helvetica Neue", Helvetica, Arial, sans-serif;
  color: ${e=>d({theme:e.theme,variable:`foreground.default`})};

  * {
    font-family: inherit;
  }
`,ya=e.div`
  font-size: 16px;
  display: grid;
  height: 100vh;
  width: 100vw;
  place-content: center;
  padding: 20px;
  text-align: center;
`,ba=e.h4`
  margin-bottom: 8px;
  color: #d93f4c;
`,xa=e.p`
  margin-bottom: 16px;
  color: #49545c;
  max-width: 500px;
`,Sa=e.pre`
  background: #f8f9f9;
  padding: 16px;
  border-radius: 4px;
  max-width: 600px;
  overflow: auto;
  text-align: left;
  white-space: pre-wrap;
`,Ca=e.button`
  margin-top: 16px;
  padding: 8px 16px;
  border: 1px solid #c1c3c5;
  border-radius: 4px;
  background: white;
  cursor: pointer;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  gap: 8px;

  &:hover {
    background: #f8f9f9;
    border-color: #68737d;
  }
`,wa=e.span`
  color: #1f73b7;
`,Ta=e.span`
  font-size: 14px;
`,Ea=class extends M.Component{constructor(e){super(e),this.state={hasError:!1,error:null,copied:!1}}static getDerivedStateFromError(e){return{hasError:!0,error:e}}componentDidCatch(e,t){window.parent.postMessage({type:`iframe-error`,error:e.toString(),errorInfo:JSON.stringify(t)},`*`)}copyErrorToClipboard=()=>{let e=this.state.error?.toString()||`Unknown error`;navigator.clipboard.writeText(e),this.setState({copied:!0}),setTimeout(()=>{this.setState({copied:!1})},ga)};render(){return this.state.hasError?(0,L.jsx)(ya,{children:(0,L.jsxs)(`div`,{children:[(0,L.jsx)(ba,{children:`An error occurred in your application`}),(0,L.jsx)(xa,{children:`To resolve this issue, please copy the error message below and paste it back into the app builder. App Builder will automatically attempt to fix this issue.`}),(0,L.jsx)(Sa,{children:this.state.error?.toString()}),(0,L.jsx)(Ca,{onClick:this.copyErrorToClipboard,title:`Click to copy error message`,children:this.state.copied?(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)(wa,{children:`Copied!`}),(0,L.jsx)(Ta,{children:`✓`})]}):(0,L.jsxs)(L.Fragment,{children:[`Copy Error`,(0,L.jsx)(Ta,{children:`📋`})]})})]})}):this.props.children}},Da=()=>{let[e,t]=(0,M.useState)(_a||`light`);(0,M.useEffect)(()=>{let e=window.ZAFClient.init();e.invoke(`resize`,{height:ma,width:ha}),e.on(`colorScheme.changed`,e=>t(e))},[]);let n={...p,colors:{...p.colors,base:e}};return(0,L.jsx)(Ea,{children:(0,L.jsx)(a,{theme:n,children:(0,L.jsx)(va,{children:(0,L.jsx)(pa,{})})})})};try{(0,_e.createRoot)(document.getElementById(`root`)).render((0,L.jsx)(Da,{}))}catch(e){console.log({error:e}),window.parent.postMessage({type:`iframe-error`,error:e.toString()},`*`)}